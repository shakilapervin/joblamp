<!-- Dashboard Sidebar
        ================================================== -->
<div class="dashboard-sidebar">
    <div class="dashboard-sidebar-inner" data-simplebar>
        <div class="dashboard-nav-container">

            <!-- Responsive Navigation Trigger -->
            <a href="#" class="dashboard-responsive-nav-trigger">
					<span class="hamburger hamburger--collapse">
						<span class="hamburger-box">
							<span class="hamburger-inner"></span>
						</span>
					</span>
                <span class="trigger-title"><?php echo e(__('Dashboard')); ?></span>
            </a>

            <!-- Navigation -->
            <div class="dashboard-nav">
                <div class="dashboard-nav-inner">

                    <ul data-submenu-title="Start">
                        <li class="<?php echo e(Route::is('dashboard') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('dashboard')); ?>">
                                <i class="icon-material-outline-dashboard"></i>
                                <?php echo e(__('Dashboard')); ?>

                            </a>
                        </li>
                        <li class="<?php echo e(Route::is('profile') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('profile')); ?>">
                                <i class="icon-material-outline-dashboard"></i>
                                <?php echo e(__('My Profile')); ?>

                            </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('messages')); ?>">
                                <i class="icon-material-outline-question-answer"></i>
                                <?php echo e(__('Messages')); ?>


                            </a>
                        </li>
                        <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'service_provider'): ?>
                            <li class="<?php echo e(Route::is('withdraw') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('withdraw')); ?>">
                                    <i class="icon-material-outline-account-balance"></i>
                                    <?php echo e(__('Withdraw')); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'service_provider'): ?>
                            <ul data-submenu-title="Organize and Manage">
                                <li class="<?php echo e(Route::is('applied.jobs') ? 'active-submenu' : ''); ?> <?php echo e(Route::is('active.jobs') ? 'active-submenu' : ''); ?> <?php echo e(Route::is('delivered.jobs') ? 'active-submenu' : ''); ?> <?php echo e(Route::is('completed.jobs') ? 'active-submenu' : ''); ?>">
                                    <a href="#"><i class="icon-material-outline-business-center"></i> Jobs</a>
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('applied.jobs')); ?>">
                                                <?php echo e(__('Applied Jobs')); ?>

                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('active.jobs')); ?>">
                                                <?php echo e(__('Active Jobs')); ?>

                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('delivered.jobs')); ?>">
                                                <?php echo e(__('Delivered Jobs')); ?>

                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('completed.jobs')); ?>">
                                                <?php echo e(__('Completed Jobs')); ?>

                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        <?php else: ?>
                            <ul data-submenu-title="Organize and Manage">
                                <li class="<?php echo e(Route::is('posted.jobs') ? 'active-submenu' : ''); ?> <?php echo e(Route::is('hired.jobs') ? 'active-submenu' : ''); ?> <?php echo e(Route::is('customer.delivered.jobs') ? 'active-submenu' : ''); ?> <?php echo e(Route::is('customer.completed.jobs') ? 'active-submenu' : ''); ?>">
                                    <a href="#"><i class="icon-material-outline-business-center"></i> Jobs</a>
                                    <ul>
                                        <li>
                                            <a href="<?php echo e(route('posted.jobs')); ?>">
                                                <?php echo e(__('Posted Jobs')); ?>

                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('hired.jobs')); ?>">
                                                <?php echo e(__('Hired Jobs')); ?>

                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('customer.delivered.jobs')); ?>">
                                                <?php echo e(__('Delivered Jobs')); ?>

                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('customer.completed.jobs')); ?>">
                                                <?php echo e(__('Completed Jobs')); ?>

                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        <?php endif; ?>
                    <?php endif; ?>
                    <ul data-submenu-title="Account">
                        <li>
                            <a href="<?php echo e(route('user-logout')); ?>">
                                <i class="icon-material-outline-power-settings-new"></i>
                                <?php echo e(__('Logout')); ?>

                            </a>
                        </li>
                    </ul>

                </div>
            </div>
            <!-- Navigation / End -->

        </div>
    </div>
</div>
<!-- Dashboard Sidebar / End -->
<?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/layouts/dashboard-sidebar.blade.php ENDPATH**/ ?>