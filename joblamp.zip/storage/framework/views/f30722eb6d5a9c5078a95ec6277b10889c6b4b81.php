<?php $__env->startSection('title'); ?>
    <?php echo e(__('Profile')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Dashboard Container -->
    <div class="dashboard-container">
    <?php echo $__env->make('frontend.layouts.dashboard-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner">

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3><?php echo e(__('My Profile')); ?></h3>

                    <!-- Breadcrumbs -->
                    <nav id="breadcrumbs" class="dark">
                        <ul>
                            <li>
                                <a href="<?php echo e(url('')); ?>"><?php echo e(__('Home')); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                            </li>
                            <li><?php echo e(__('My Profile')); ?></li>
                        </ul>
                    </nav>
                </div>

                <!-- Row -->
                <div class="row">

                    <!-- Dashboard Box -->
                    <div class="col-xl-12">
                        <div class="dashboard-box margin-top-0">

                            <!-- Headline -->
                            <div class="headline">
                                <h3 class="d-block" style="overflow: hidden">
                                    <i class="icon-material-outline-account-circle"></i>
                                    <?php echo e(__('Profile Details')); ?>

                                    <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'service_provider'): ?>
                                        <?php if(\Illuminate\Support\Facades\Auth::user()->promoted == 'false' || \Illuminate\Support\Facades\Auth::user()->promotion_expire < date('Y-m-d')): ?>
                                            <div class="d-inline-block float-right ml-2 ">
                                                <a href="<?php echo e(route('promote.profile')); ?>"
                                                   class="button"><?php echo e(__('Promote Your Profile')); ?></a>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <div class="d-inline-block float-right">
                                        <a href="<?php echo e(route('edit.profile')); ?>"
                                           class="button"><?php echo e(__('Edit Profile')); ?></a>
                                    </div>
                                </h3>

                            </div>

                            <div class="content with-padding padding-bottom-0">
                                <div class="row profile-general text-center">
                                    <div class="col-md-12">
                                        <div class="avatar-wrapper">
                                            <?php if(!empty($user->profile_pic)): ?>
                                                <img class="profile-pic"
                                                     src="<?php echo e(asset('public/profile')); ?>/<?php echo e($user->profile_pic); ?>" alt=""/>
                                            <?php else: ?>
                                                <img class="profile-pic"
                                                     src="<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                     alt=""/>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <h3>
                                            <?php echo e($user->first_name); ?>

                                            <?php echo e($user->last_name); ?>

                                        </h3>
                                    </div>
                                </div>
                                <div class="row details">
                                    <div class="col-md-12">
                                        <b><?php echo e(__('Email Address')); ?></b> : <?php echo e($user->email); ?>

                                    </div>
                                    <div class="col-md-12">
                                        <b><?php echo e(__('Mobile Number')); ?></b> : <?php echo e($user->mobile_number); ?>

                                    </div>
                                    <div class="col-md-12">
                                        <b><?php echo e(__('User Type')); ?></b> :
                                        <?php if($user->user_type == 'service_provider'): ?>
                                            <?php echo e(__('Service Provider')); ?>

                                        <?php else: ?>
                                            <?php echo e(__('Customer')); ?>

                                        <?php endif; ?>
                                    </div>
                                    <?php if(!empty($user->address_line_1)): ?>
                                        <div class="col-md-12">
                                            <b><?php echo e(__('Address Line 1')); ?></b> : <?php echo e($user->address_line_1); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if(!empty($user->address_line_2)): ?>
                                        <div class="col-md-12">
                                            <b><?php echo e(__('Address Line 2')); ?></b> : <?php echo e($user->address_line_2); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if(!empty($user->city)): ?>
                                        <div class="col-md-12">
                                            <b><?php echo e(__('City')); ?></b> : <?php echo e($user->userCity->name); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if(!empty($user->state)): ?>
                                        <div class="col-md-12">
                                            <b><?php echo e(__('State')); ?></b> : <?php echo e($user->userState->name); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if(!empty($user->country)): ?>
                                        <div class="col-md-12">
                                            <b><?php echo e(__('Country')); ?></b> : <?php echo e($user->userCountry->name); ?>

                                        </div>
                                    <?php endif; ?>
                                    <?php if(!empty($user->pincode)): ?>
                                        <div class="col-md-12">
                                            <b><?php echo e(__('Pincode')); ?></b> : <?php echo e($user->pincode); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
                <!-- Row / End -->

            </div>
        </div>
        <!-- Dashboard Content / End -->

    </div>
    <!-- Dashboard Container / End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/profile/profile.blade.php ENDPATH**/ ?>