<?php $__env->startSection('content'); ?>
    <div class="single-page-header freelancer-header">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="single-page-header-inner">
                        <div class="left-side">
                            <div class="header-image freelancer-avatar">
                                <?php if(!empty($user->profile_pic)): ?>
                                    <img src="<?php echo e(asset('')); ?>/<?php echo e($user->profile_pic); ?>"
                                         alt=""/>
                                <?php else: ?>
                                    <img
                                        src="<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                        alt=""/>
                                <?php endif; ?>
                            </div>
                            <div class="header-details">
                                <h3><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></h3>
                                <ul>
                                    <li>
                                        <div class="star-rating"
                                             data-rating="<?php echo e($user->userRating); ?>"></div>
                                    </li>
                                    <li>
                                        <?php echo e($user->country_name); ?>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">

            <!-- Content -->
            <div class="col-xl-12 col-lg-12 content-right-offset">

                <!-- Boxed List -->
                <div class="boxed-list margin-bottom-60">
                    <div class="boxed-list-headline">
                        <h3><i class="icon-material-outline-thumb-up"></i> <?php echo e(__('Work History and Feedback')); ?></h3>
                    </div>
                    <ul class="boxed-list-ul">
                        <?php $__currentLoopData = $userFeedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="boxed-list-item">
                                <!-- Content -->
                                <div class="item-content">
                                    <h4>
                                        <?php echo e($feedback->first_name); ?> <?php echo e($feedback->last_name); ?>

                                        <span><?php echo e(__('Rated as Freelancer')); ?></span>
                                    </h4>
                                    <div class="item-details margin-top-10">
                                        <div class="star-rating" data-rating="<?php echo e($feedback->rating); ?>"></div>
                                        <div class="detail-item"><i class="icon-material-outline-date-range"></i>
                                            <?php echo e(\Carbon\Carbon::parse($feedback->created_at)->format('Y-m-d')); ?>

                                        </div>
                                    </div>
                                    <div class="item-description">
                                        <p><?php echo e($feedback->feedback); ?></p>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                </div>
                <!-- Boxed List / End -->

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/profile/public.blade.php ENDPATH**/ ?>