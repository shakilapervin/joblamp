<!-- Sidebar wrapper start -->
<nav id="sidebar" class="sidebar-wrapper">

    <!-- Sidebar brand start  -->
    <div class="sidebar-brand">
        <a target="_blank" href="<?php echo e(route('home')); ?>" class="logo">JobLamp</a>
    </div>
    <!-- Sidebar brand end  -->

    <!-- User profile start -->
    <div class="sidebar-user-details">
        <div class="user-profile">
            <img src="<?php echo e(admin_asset('')); ?>/img/user2.png" class="profile-thumb" alt="User Thumb">
            <span class="status-label"></span>
        </div>
        <h6 class="profile-name"><?php echo e(\Illuminate\Support\Facades\Auth::user()->first_name); ?> <?php echo e(\Illuminate\Support\Facades\Auth::user()->last_name); ?></h6>
        <div class="profile-actions">
            <a href="<?php echo e(route('admin-logout')); ?>" class="red" data-toggle="tooltip" data-placement="top" title=""
               data-original-title="<?php echo e(__('Logout')); ?>">
                <i class="icon-power1"></i>
            </a>
        </div>
    </div>
    <!-- User profile end -->

    <!-- Sidebar content start -->
    <div class="sidebar-content">

        <!-- sidebar menu start -->
        <div class="sidebar-menu">
            <ul>
                <li class="<?php echo e(Route::is('admin.dashboard') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                       class="<?php echo e(Route::is('admin.dashboard') ? 'current-page' : ''); ?>">
                        <i class="icon-home2"></i>
                        <span class="menu-text">Dashboards</span>
                    </a>
                </li>
                <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'admin'): ?>
                    <li class="sidebar-dropdown <?php echo e(Route::is('admin.country') ? 'active' : ''); ?> <?php echo e(Route::is('admin.states') ? 'active' : ''); ?> <?php echo e(Route::is('admin.add.state') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.state') ? 'active' : ''); ?> <?php echo e(Route::is('admin.add.country') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.country') ? 'active' : ''); ?> <?php echo e(Route::is('admin.cities') ? 'active' : ''); ?> <?php echo e(Route::is('admin.add.city') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.city') ? 'active' : ''); ?> <?php echo e(Route::is('admin.cities') ? 'active' : ''); ?> <?php echo e(Route::is('admin.add.city') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.city') ? 'active' : ''); ?>">
                        <a href="javascript:void(0);">
                            <i class="icon-map-pin"></i>
                            <span class="menu-text"><?php echo e(__('Locations')); ?></span>
                        </a>
                        <div class="sidebar-submenu">
                            <ul>
                                <li>
                                    <a class="<?php echo e(Route::is('admin.country') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.add.country') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.country') ? 'active' : ''); ?>"
                                       href="<?php echo e(route('admin.country')); ?>"><?php echo e(__('Countries')); ?></a>
                                </li>
                                <li>
                                    <a class="<?php echo e(Route::is('admin.states') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.add.state') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.edit.state') ? 'current-page' : ''); ?>"
                                       href="<?php echo e(route('admin.states')); ?> "><?php echo e(__('States')); ?></a>
                                </li>

                                <li>
                                    <a class="<?php echo e(Route::is('admin.cities') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.add.city') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.edit.city') ? 'current-page' : ''); ?>"
                                       href="<?php echo e(route('admin.cities')); ?> "><?php echo e(__('Cities')); ?></a>
                                </li>
                            </ul>
                        </div>
                    </li>

                    <li class="<?php echo e(Route::is('admin.customers') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.customer') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.customers')); ?>"
                           class="<?php echo e(Route::is('admin.customers') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.edit.customer') ? 'current-page' : ''); ?>">
                            <i class="icon-users"></i>
                            <span class="menu-text"><?php echo e(__('Task Giver')); ?></span>
                        </a>
                    </li>

                    <li class="sidebar-dropdown <?php echo e(Route::is('admin.job.categories') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.job.category') ? 'active' : ''); ?> <?php echo e(Route::is('admin.add.job.category') ? 'active' : ''); ?>

                    <?php echo e(Route::is('admin.job.subcategories') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.job.subcategory') ? 'active' : ''); ?> <?php echo e(Route::is('admin.add.job.subcategory') ? 'active' : ''); ?>

                        ">
                        <a href="javascript:void(0);">
                            <i class="icon-map-pin"></i>
                            <span class="menu-text"><?php echo e(__('Job Category')); ?></span>
                        </a>
                        <div class="sidebar-submenu">
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('admin.job.categories')); ?>"
                                       class="<?php echo e(Route::is('admin.job.categories') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.edit.job.category') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.add.job.category') ? 'current-page' : ''); ?>">
                                        <?php echo e(__('Categories')); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('admin.job.subcategories')); ?>"
                                       class="<?php echo e(Route::is('admin.job.subcategories') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.edit.job.subcategory') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.add.job.subcategory') ? 'current-page' : ''); ?>">
                                        <?php echo e(__('Sub Categories')); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>

                    </li>

                    <li class="<?php echo e(Route::is('admin.contractors') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.contractor') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.contractors')); ?>"
                           class="<?php echo e(Route::is('admin.contractors') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.edit.contractor') ? 'current-page' : ''); ?>">
                            <i class="icon-user-plus"></i>
                            <span class="menu-text"><?php echo e(__('Task Worker')); ?></span>
                        </a>

                    </li>
                <?php endif; ?>
                <li class="sidebar-dropdown <?php echo e(Route::is('admin.jobs') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.job') ? 'active' : ''); ?> <?php echo e(Route::is('admin.view.job') ? 'active' : ''); ?> <?php echo e(Route::is('admin.disputed.jobs') ? 'active' : ''); ?> <?php echo e(Route::is('admin.view.dispute.job') ? 'active' : ''); ?>">
                    <a href="javascript:void(0);">
                        <i class="icon-book"></i>
                        <span class="menu-text"><?php echo e(__('Jobs')); ?></span>
                    </a>

                    <div class="sidebar-submenu">
                        <ul>
                            <li>
                                <a href="<?php echo e(route('admin.jobs')); ?>"
                                   class="<?php echo e(Route::is('admin.jobs') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.edit.job') ? 'current-page' : ''); ?>">
                                    <span class="menu-text"><?php echo e(__('All Jobs')); ?></span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.disputed.jobs')); ?>"
                                   class="<?php echo e(Route::is('admin.disputed.jobs') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.view.dispute.job') ? 'current-page' : ''); ?>">
                                    <?php echo e(__('Disputed Jobs')); ?>

                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'admin'): ?>
                    <li class="<?php echo e(Route::is('admin.subscription.plans') ? 'active' : ''); ?> <?php echo e(Route::is('admin.subscription.plan.add') ? 'active' : ''); ?> <?php echo e(Route::is('admin.subscription.plan.edit') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.subscription.plans')); ?>"
                           class="<?php echo e(Route::is('admin.subscription.plans') ? 'current-page' : ''); ?>  <?php echo e(Route::is('admin.subscription.plan.add') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.subscription.plan.edit') ? 'current-page' : ''); ?>">
                            <i class="icon-list"></i>
                            <span class="menu-text"><?php echo e(__('Subscription Plans')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="<?php echo e(Route::is('admin.transactions') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.transactions')); ?>"
                       class="<?php echo e(Route::is('admin.transactions') ? 'current-page' : ''); ?>">
                        <i class="icon-attach_money"></i>
                        <span class="menu-text">Transactions</span>
                    </a>
                </li>
                <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'admin'): ?>
                    <li class="<?php echo e(Route::is('edit.charge') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('edit.charge')); ?>"
                           class="<?php echo e(Route::is('edit.charge') ? 'current-page' : ''); ?>">
                            <i class="icon-attach_money"></i>
                            <span class="menu-text"><?php echo e(__('Charge and Commission')); ?></span>
                        </a>
                    </li>
                    <li class="<?php echo e(Route::is('admin.cs.persons') ? 'active' : ''); ?> <?php echo e(Route::is('admin.edit.cs.person') ? 'active' : ''); ?> <?php echo e(Route::is('admin.create.cs.person') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.cs.persons')); ?>"
                           class="<?php echo e(Route::is('admin.cs.persons') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.edit.cs.person') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.create.cs.person') ? 'current-page' : ''); ?>">
                            <i class="icon-user-check"></i>
                            <span class="menu-text"><?php echo e(__('Customer Service Person')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
                <li class="<?php echo e(Route::is('admin.supports') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('admin.supports')); ?>"
                       class="<?php echo e(Route::is('admin.supports') ? 'current-page' : ''); ?>">
                        <i class="icon-help"></i>
                        <span class="menu-text">Contact Supports</span>
                    </a>
                </li>
                <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'admin'): ?>
                    <li class="sidebar-dropdown <?php echo e(Route::is('admin.banners') ? 'active' : ''); ?> <?php echo e(Route::is('admin.create.banner') ? 'active' : ''); ?> <?php echo e(Route::is('admin.page.privacy.policy') ? 'active' : ''); ?> <?php echo e(Route::is('admin.page.terms.conditions') ? 'active' : ''); ?> <?php echo e(Route::is('admin.page.about.us') ? 'active' : ''); ?>">
                        <a href="javascript:void(0);">
                            <i class="icon-laptop_mac"></i>
                            <span class="menu-text"><?php echo e(__('Frontend')); ?></span>
                        </a>

                        <div class="sidebar-submenu">
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('admin.banners')); ?>"
                                       class="<?php echo e(Route::is('admin.banners') ? 'current-page' : ''); ?> <?php echo e(Route::is('admin.create.banner') ? 'current-page' : ''); ?>">
                                        <span class="menu-text"><?php echo e(__('Banner Management')); ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('admin.page.privacy.policy')); ?>"
                                       class="<?php echo e(Route::is('admin.page.privacy.policy') ? 'current-page' : ''); ?>">
                                        <span class="menu-text"><?php echo e(__('Privacy Policy')); ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('admin.page.terms.conditions')); ?>"
                                       class="<?php echo e(Route::is('admin.page.terms.conditions') ? 'current-page' : ''); ?>">
                                        <span class="menu-text"><?php echo e(__('Terms and Conditions')); ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('admin.page.about.us')); ?>"
                                       class="<?php echo e(Route::is('admin.page.about.us') ? 'current-page' : ''); ?>">
                                        <span class="menu-text"><?php echo e(__('About Us')); ?></span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="<?php echo e(Route::is('admin.skills') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.skills')); ?>"
                           class="<?php echo e(Route::is('admin.skills') ? 'current-page' : ''); ?>">
                            <i class="icon-account_box"></i>
                            <span class="menu-text">Skill Management</span>
                        </a>
                    </li>
                    <li class="<?php echo e(Route::is('admin.lotto.users') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.lotto.users')); ?>"
                           class="<?php echo e(Route::is('admin.lotto.users') ? 'current-page' : ''); ?>">
                            <i class="icon-user-plus"></i>
                            <span class="menu-text"><?php echo e(__('Lotto Users')); ?></span>
                        </a>
                    </li>
                    <li class="<?php echo e(Route::is('admin.create.notification') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.create.notification')); ?>"
                           class="<?php echo e(Route::is('admin.create.notification') ? 'current-page' : ''); ?>">
                            <i class="icon-bell"></i>
                            <span class="menu-text"><?php echo e(__('Create Notification')); ?></span>
                        </a>
                    </li>
                    <li class="<?php echo e(Route::is('admin.lotto.prizes') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('admin.lotto.prizes')); ?>"
                           class="<?php echo e(Route::is('admin.lotto.prizes') ? 'current-page' : ''); ?>">
                            <i class="icon-gift"></i>
                            <span class="menu-text"><?php echo e(__('Lotto Prizes')); ?></span>
                        </a>
                    </li>
                    <li class="sidebar-dropdown <?php echo e(Route::is('admin.withdraw.not.paid') ? 'active' : ''); ?> <?php echo e(Route::is('admin.withdraw.paid') ? 'active' : ''); ?> <?php echo e(Route::is('admin.withdraw.pending.payouts') ? 'active' : ''); ?>">
                        <a href="javascript:void(0);">
                            <i class="icon-attach_money"></i>
                            <span class="menu-text"><?php echo e(__('Withdraw Requests')); ?></span>
                        </a>

                        <div class="sidebar-submenu">
                            <ul>
                                <li>
                                    <a href="<?php echo e(route('admin.withdraw.not.paid')); ?>"
                                       class="<?php echo e(Route::is('admin.withdraw.not.paid') ? 'current-page' : ''); ?>">
                                        <span class="menu-text"><?php echo e(__('Not Paid')); ?></span>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('admin.withdraw.paid')); ?>"
                                       class="<?php echo e(Route::is('admin.withdraw.paid') ? 'current-page' : ''); ?>">
                                        <?php echo e(__('Paid')); ?>

                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo e(route('admin.withdraw.pending.payouts')); ?>"
                                       class="<?php echo e(Route::is('admin.withdraw.pending.payouts') ? 'current-page' : ''); ?>">
                                        <?php echo e(__('Pending Payouts')); ?>

                                    </a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="<?php echo e(url('/languages')); ?>">
                            <i class="icon-attach_money"></i>
                            <span class="menu-text"><?php echo e(__('Languages')); ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- sidebar menu end -->

    </div>
    <!-- Sidebar content end -->

</nav>
<!-- Sidebar wrapper end -->
<!-- Page content start  -->
<div class="page-content">
<?php /**PATH D:\wamp64\www\joblamp\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>