<?php $__env->startSection('style'); ?>
    <!-- Data Tables -->
    <link rel="stylesheet" href="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.bs4.css"/>
    <link rel="stylesheet" href="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.bs4-custom.css"/>
    <link href="<?php echo e(admin_asset('')); ?>/vendor/datatables/buttons.bs.css" rel="stylesheet"/>
    <!-- Datepicker css -->
    <link rel="stylesheet" href="<?php echo e(admin_asset('')); ?>/vendor/datepicker/css/classic.css"/>
    <link rel="stylesheet" href="<?php echo e(admin_asset('')); ?>/vendor/datepicker/css/classic.date.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(__('Job List')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main container start -->
    <div class="main-container">

        <!-- Page header start -->
        <div class="page-header">

            <!-- Breadcrumb start -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><?php echo e(__('Job List')); ?></li>
            </ol>
            <!-- Breadcrumb end -->
        </div>
        <!-- Page header end -->

        <!-- Row start -->
        <div class="row gutters">
            <div class="col-sm-12">
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <form action="<?php echo e(route('admin.jobs')); ?>" method="get" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row no-gutters">
                                <div class="col-md-4 pl-0">
                                    <div class="form-group row">
                                        <div class="col-sm-12 pl-0">
                                            <input type="text"
                                                   class="form-control form-control datePicker"
                                                   id="colFormLabelSm" placeholder="<?php echo e(__('Date')); ?>" name="date">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 pl-0">
                                    <div class="form-group row">
                                        <div class="col-sm-12 pl-0">
                                            <select name="status" class="form-control">
                                                <option value="">Select Job Status</option>
                                                <option value="opened">Pending</option>
                                                <option value="hired">In Progress</option>
                                                <option value="completed">Completed</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4 pl-0">
                                    <div class="form-group row">
                                        <div class="col-sm-12 pl-0">
                                            <button type="submit" class="btn btn-primary"><?php echo e(__('Filter')); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                        <div class="card-title">
                            <?php echo e(__('Job List')); ?>

                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="datatable table table-bordered">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th><?php echo e(__('Job ID')); ?></th>
                                    <th><?php echo e(__('Posted By')); ?></th>
                                    <th><?php echo e(__('Title')); ?></th>
                                    <th><?php echo e(__('Category')); ?></th>
                                    <th><?php echo e(__('Date')); ?></th>
                                    <th><?php echo e(__('Job Charge')); ?></th>
                                    <th><?php echo e(__('TG Commission')); ?></th>
                                    <th><?php echo e(__('TW Commission')); ?></th>
                                    <th><?php echo e(__('TW Payment')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <th width="10%"><?php echo e(__('Action')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $sl = 0;
                                ?>
                                <?php if($noJob != true): ?>
                                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $sl++;
                                        ?>
                                        <tr>
                                            <td>
                                                <?php echo e($sl); ?>

                                            </td>
                                            <td>
                                                <?php echo e($job->job_id); ?>

                                            </td>
                                            <td>
                                                <?php echo e($job->creatorDetails->first_name); ?> <?php echo e($job->creatorDetails->last_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($job->title); ?>

                                            </td>
                                            <td>
                                                <?php echo e($job->categoryInfo->name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($job->created_at->toDateString()); ?>

                                            </td>
                                            <?php
                                                if ($job->status == 'hired' || $job->status == 'completed' || $job->status == 'disputed'){
                                                $jobCharge = \App\JobApplication::where('job_id',$job->id)
                                                            ->whereIn('status',['hired','completed'])
                                                            ->first()->bid_amount;
                                                $tgCommission = ($jobCharge*$charge->customer_charge)/100;
                                                $twCommission = ($jobCharge*$charge->worker_charge)/100;

                                                }else{
                                                    $jobCharge = 0;
                                                    $tgCommission = 0;
                                                    $twCommission = 0;
                                                }
                                            ?>
                                            <td>
                                                <?php echo e($jobCharge); ?>

                                            </td>
                                            <td>
                                                <?php echo e($tgCommission); ?>

                                            </td>
                                            <td>
                                                <?php echo e($twCommission); ?>

                                            </td>
                                            <td>
                                                <?php echo e($jobCharge-$twCommission); ?>

                                            </td>
                                            <td>
                                                <?php if($job->status == 'opened'): ?>
                                                    <span class="badge badge-primary"><?php echo e(__('Opened')); ?></span>
                                                <?php elseif($job->status == 'hired'): ?>
                                                    <span class="badge badge-warning"><?php echo e(__('Pending')); ?></span>
                                                <?php elseif($job->status == 'disputed'): ?>
                                                    <span class="badge badge-danger"><?php echo e(__('Disputed')); ?></span>
                                                <?php else: ?>
                                                    <span class="badge badge-success"><?php echo e(__('Completed')); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="dropdown">
                                                    <button class="btn btn-primary dropdown-toggle" type="button"
                                                            id="dropdownMenuButton" data-toggle="dropdown"
                                                            aria-haspopup="true" aria-expanded="false">
                                                        <?php echo e(__('Actions')); ?>

                                                    </button>
                                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('admin.view.job', $job->id)); ?>"><?php echo e(__('Details')); ?></a>
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('admin.edit.job', $job->id)); ?>"><?php echo e(__('Edit')); ?></a>
                                                        <a class="dropdown-item"
                                                           href="<?php echo e(route('admin.delete.job', $job->id)); ?>"
                                                           onclick="return confirm('Are you sure?')"><?php echo e(__('Delete')); ?></a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center"><?php echo e(__('No Job Found')); ?></td>
                                    </tr>
                                <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->

    </div>
    <!-- Main container end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Data Tables -->
    <script src="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.min.js"></script>
    <script src="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.bootstrap.min.js"></script>
    <!-- Datepickers -->
    <script src="<?php echo e(admin_asset('')); ?>/vendor/datepicker/js/picker.js"></script>
    <script src="<?php echo e(admin_asset('')); ?>/vendor/datepicker/js/picker.date.js"></script>
    <script>
        $(document).ready(function () {
            $('.datatable').dataTable();
            $('.datePicker').pickadate({
                format: 'yyyy-mm-dd',
                formatSubmit: 'yyyy-mm-dd',
                hiddenName: true
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/admin/job/index.blade.php ENDPATH**/ ?>