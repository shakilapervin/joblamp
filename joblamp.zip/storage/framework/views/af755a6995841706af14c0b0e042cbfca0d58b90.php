<?php $__env->startSection('content'); ?>
    <!-- Intro Banner
    ================================================== -->
    <div class="hero-banner">
        <div class="hero-slider">
            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="hero-item" style="background: url('<?php echo e(asset('public/'.$banner->image)); ?>')">
                <div class="hero-title">
                    <?php echo e($banner->title); ?>

                </div>
                <div class="overlay"></div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>


    <!-- Content
    ================================================== -->
    <!-- Category Boxes -->
    <div class="section margin-top-65">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">

                    <div class="section-headline centered margin-bottom-50">
                        <h3>Popular Job Categories</h3>
                    </div>

                    <!-- Category Boxes Container -->
                    <div class="categories-container">
                    <?php if(!empty($jobcategories)): ?>
                        <?php $__currentLoopData = $jobcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Category Box -->
                                <a href="<?php echo e(route('job-list')); ?>/?category_id=<?php echo e($jobcategory->id); ?>"
                                   class="category-box">
                                    <div class="category-box-icon">
                                        <i class="<?php echo e($jobcategory->icon); ?> "></i>
                                    </div>
                                    <div class="category-box-counter">
                                        <?php echo e(number_format($jobcategory->totalJob,0,',',',')); ?>

                                    </div>
                                    <div class="category-box-content">
                                        <h3><?php echo e($jobcategory->name); ?></h3>
                                        <p><?php echo e($jobcategory->description); ?></p>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- Category Boxes / End -->


    <!-- Features Jobs -->
    <div class="section gray margin-top-45 padding-top-65 padding-bottom-75">
        <div class="container">
            <div class="row">
                <div class="col-xl-12">

                    <!-- Section Headline -->
                    <div class="section-headline margin-top-0 margin-bottom-35">
                        <h3><?php echo e(__('Latest Jobs')); ?></h3>
                        <a href="<?php echo e(route('job-list')); ?>" class="headline-link"><?php echo e(__('Browse All Jobs')); ?></a>
                    </div>

                    <!-- Jobs Container -->
                    <div class="listings-container compact-list-layout margin-top-35">
                    <?php if(!empty($jobs)): ?>
                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Job Listing -->
                                <a href="<?php echo e(route('job.details',encrypt($job->id))); ?>"
                                   class="job-listing with-apply-button">

                                    <!-- Job Listing Details -->
                                    <div class="job-listing-details">

                                        <!-- Logo -->
                                        <div class="job-listing-company-logo">
                                            <?php if(!empty($job->creatorDetails->profile_pic)): ?>
                                                <img src="<?php echo e(asset('')); ?>/<?php echo e($job->creatorDetails->profile_pic); ?>"
                                                     alt=""/>
                                            <?php else: ?>
                                                <img
                                                    src="<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                    alt=""/>
                                            <?php endif; ?>
                                        </div>

                                        <!-- Details -->
                                        <div class="job-listing-description">
                                            <h3 class="job-listing-title"><?php echo e($job->title); ?></h3>

                                            <!-- Job Listing Footer -->
                                            <div class="job-listing-footer">
                                                <ul>
                                                    <li>
                                                        <i class="icon-material-outline-business"></i> <?php echo e($job->creatorDetails->first_name); ?> <?php echo e($job->creatorDetails->last_name); ?>

                                                        <div class="verified-badge" title="Verified Employer"
                                                             data-tippy-placement="top"></div>
                                                    </li>
                                                    <li>
                                                        <i class="icon-material-outline-location-on"></i> <?php echo e($job->address); ?>

                                                    </li>
                                                    <li>
                                                        <i class="icon-material-outline-account-balance-wallet"></i>
                                                        $<?php echo e($job->fee_range_min); ?>-<?php echo e($job->fee_range_max); ?>

                                                    </li>
                                                    <li>
                                                        <i class="icon-material-outline-access-time"></i>
                                                        <?php echo e($job->created_at->diffForHumans()); ?>

                                                    </li>
                                                </ul>
                                            </div>
                                        </div>

                                        <!-- Apply Button -->
                                        <span class="list-apply-button ripple-effect"><?php echo e(__('View Details')); ?></span>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                    <!-- Jobs Container / End -->

                </div>
            </div>
        </div>
    </div>
    <!-- Featured Jobs / End -->



    <!-- Highest Rated Freelancers -->
    <div class="section padding-top-65 padding-bottom-70 full-width-carousel-fix">
        <div class="container">
            <div class="row">

                <div class="col-xl-12">
                    <!-- Section Headline -->
                    <div class="section-headline margin-top-0 margin-bottom-25">
                        <h3><?php echo e(__('Highest Rated Task Workers')); ?></h3>
                        
                        
                    </div>
                </div>

                <div class="col-xl-12">
                    <div class="default-slick-carousel freelancers-container freelancers-grid-layout">
                    <?php if(!empty($popularWorkers)): ?>
                        <?php $__currentLoopData = $popularWorkers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popularWorker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!--Freelancer -->
                                <div class="freelancer">

                                    <!-- Overview -->
                                    <div class="freelancer-overview">
                                        <div class="freelancer-overview-inner">
                                            <!-- Avatar -->
                                            <div class="freelancer-avatar">
                                                <div class="verified-badge"></div>
                                                <a href="<?php echo e(route('public.profile',encrypt($popularWorker->id))); ?>">
                                                    <?php if(!empty($popularWorker->profile_pic)): ?>
                                                        <img src="<?php echo e(asset('public/profile')); ?>/<?php echo e($popularWorker->profile_pic); ?>"
                                                             alt=""/>
                                                    <?php else: ?>
                                                        <img
                                                            src="<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                            alt=""/>
                                                    <?php endif; ?>
                                                </a>
                                            </div>

                                            <!-- Name -->
                                            <div class="freelancer-name">
                                                <h4>
                                                    <a href="<?php echo e(route('public.profile',encrypt($popularWorker->id))); ?>">
                                                        <?php echo e($popularWorker->first_name); ?> <?php echo e($popularWorker->last_name); ?>

                                                    </a>
                                                </h4>
                                            </div>
                                            <!-- Rating -->
                                            <div class="freelancer-rating">
                                                <div class="star-rating"
                                                     data-rating="<?php echo e($popularWorker->userRating); ?>"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Details -->
                                    <div class="freelancer-details">
                                        <div class="freelancer-details-list">
                                            <ul>
                                                <li>
                                                    <?php echo e(__('Location')); ?>

                                                    <strong>
                                                        <i class="icon-material-outline-location-on"></i>
                                                        <?php echo e($popularWorker->country_name); ?>

                                                    </strong>
                                                </li>
                                            </ul>
                                        </div>
                                        <a href="<?php echo e(route('public.profile',encrypt($popularWorker->id))); ?>"
                                           class="button button-sliding-icon ripple-effect"><?php echo e(__('View Profile')); ?> <i
                                                class="icon-material-outline-arrow-right-alt"></i></a>
                                    </div>
                                </div>
                                <!-- Freelancer / End -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- Highest Rated Freelancers / End-->


    <!-- Membership Plans -->
    <div class="section padding-top-60 padding-bottom-75">
        <div class="container">
            <div class="row">

                <div class="col-xl-12">
                    <!-- Section Headline -->
                    <div class="section-headline centered margin-top-0 margin-bottom-35">
                        <h3><?php echo e(__('Membership Plans')); ?></h3>
                    </div>
                </div>


                <div class="col-xl-12">
                    <!-- Pricing Plans Container -->
                    <div class="pricing-plans-container">
                    <?php $__currentLoopData = $subscriptionPlans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Plan -->
                            <div class="pricing-plan <?php if($plan->recommended == 1): ?> recommended <?php endif; ?>">
                                <h3><?php echo e(__($plan->title)); ?></h3>
                                <p class="margin-top-10">
                                    <?php echo e(__($plan->description)); ?>

                                </p>
                                <div class="pricing-plan-label billed-monthly-label">
                                    <strong>$<?php echo e($plan->default_price); ?></strong>/ <?php echo e(__('monthly')); ?>

                                </div>
                                <div class="pricing-plan-label billed-yearly-label">
                                    <strong>$<?php echo e($plan->default_price*12); ?></strong>/ <?php echo e(__('yearly')); ?></div>
                                <div class="pricing-plan-features">
                                    <strong><?php echo e(__('Features of')); ?> <?php echo e(__($plan->title)); ?></strong>
                                    <ul>
                                        <?php $__currentLoopData = $plan->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e(__($feature->content)); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <a href="<?php echo e(route('subscription.checkout',encrypt($plan->id))); ?>"
                                   class="button full-width margin-top-20">
                                    <?php echo e(__('Buy Now')); ?>

                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>

            </div>
        </div>
    </div>
    <!-- Membership Plans / End-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>