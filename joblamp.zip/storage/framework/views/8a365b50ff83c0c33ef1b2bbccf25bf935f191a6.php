<?php $__env->startSection('title'); ?>
    <?php echo e($job->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/vendor/rating/dist/star-rating.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend/vendor/dropify/css/dropify.min.css')); ?>">
    <style>
        .message-reply {
            position: relative;
            display: flex;
            margin-bottom: 40px;
        }

        .message-picker {
            list-style: none;
            position: absolute;
            bottom: 10px;
            left: 0;
            margin: 0;
        }

        .message-picker li span {
            font-size: 20px !important;
            color: #f39c12;
            cursor: pointer;
        }

        .message-text {
            position: relative;
        }

        .message-time {
            position: absolute;
            width: 200px;
            bottom: -30px;
            left: 0;
            color: grey;
            font-size: 12px !important;
        }

        .me .message-time {
            right: 0;
            text-align: right;
            left: inherit;
        }

        .message-bubble {
            margin-bottom: 35px !important;
        }

        .dropify-wrapper {
            height: 250px;
            margin-top: 24px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Titlebar
    ================================================== -->
    <div class="single-page-header" data-background-image="<?php echo e(frontend_asset('')); ?>/images/single-job.jpg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="single-page-header-inner">
                        <div class="left-side">
                            <div class="header-image">
                                <a href="single-company-profile.html">
                                    <?php if(!empty($job->creatorDetails->profile_pic)): ?>
                                        <img src="<?php echo e(asset('')); ?>/<?php echo e($job->creatorDetails->profile_pic); ?>" alt=""/>
                                    <?php else: ?>
                                        <img
                                            src="<?php echo e(asset('assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                            alt=""/>
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="header-details">
                                <h3><?php echo e($job->title); ?></h3>
                                <h5>
                                    <?php echo e(__('About the Employer')); ?>

                                </h5>
                                <ul>
                                    <li>
                                        <a href="single-company-profile.html">
                                            <i class="icon-material-outline-business"></i>
                                            <?php echo e($job->creatorDetails->first_name); ?> <?php echo e($job->creatorDetails->last_name); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <div class="star-rating"
                                             data-rating="<?php echo e(calculateRating(\App\Rating::where('user_id',$job->creatorDetails->id)->get())); ?>"></div>
                                    </li>
                                    <li>
                                        <?php echo e($job->creatorDetails->userCountry->name); ?>

                                    </li>
                                    <li>
                                        <div class="verified-badge-with-title">Verified</div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="right-side">
                            <div class="salary-box">
                                <div class="salary-type"><?php echo e(__('Fee Range')); ?></div>
                                <div class="salary-amount">$<?php echo e($job->fee_range_min); ?> - $<?php echo e($job->fee_range_max); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Page Content
    ================================================== -->
    <div class="container">
        <div class="row">

            <!-- Content -->
            <div class="col-xl-8 col-lg-8 content-right-offset">

                <div class="single-page-section">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <h3 class="margin-bottom-25">
                        <?php echo e(__('Job Description')); ?>

                    </h3>
                    <p>
                        <?php echo e($job->description); ?>

                    </p>
                    <div class="messages-container margin-top-0">

                        <div class="messages-container-inner">
                            <!-- Message Content -->
                            <div class="message-content">

                                <!-- Message Content Inner -->
                                <div class="message-content-inner"></div>
                                <!-- Message Content Inner / End -->
                            <?php if($job->status != 'completed'): ?>
                                <!-- Reply Area -->
                                    <div class="message-reply">
                                <textarea cols="1" rows="1" placeholder="Your Message" data-autoresize
                                          class="message-data"></textarea>
                                        <button class="button apply-now-button popup-with-zoom-anim"
                                                style="background: transparent; color: #D5152F;padding: 10px; position: absolute;top: 85%;"
                                                href="#file-dialog">
                                            <i class="icon-feather-paperclip"></i>
                                        </button>
                                        <button class="button ripple-effect"
                                                onclick="postChat();"><?php echo e(__('Send')); ?></button>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <!-- Message Content -->

                        </div>
                    </div>
                </div>
            </div>


            <!-- Sidebar -->
            <div class="col-xl-4 col-lg-4">
                <div class="sidebar-container">
                    <?php if($job->status == 'delivered'): ?>
                        <a href="<?php echo e(route('approve.job.delivery',encrypt($jobId))); ?>"
                           class="apply-now-button bg-success">
                            <?php echo e(__('Approve')); ?>

                            <i class="icon-material-outline-arrow-right-alt"></i>
                        </a>
                        <a href="#small-dialog" class="apply-now-button bg-danger popup-with-zoom-anim">
                            <?php echo e(__('Dispute')); ?>

                            <i class="icon-material-outline-arrow-right-alt"></i>
                        </a>
                        <div class="sidebar-widget">
                            <div class="job-overview">
                                <div class="job-overview-headline">
                                    <?php echo e(__('Job Delivery Details')); ?>

                                </div>
                                <div class="job-overview-inner">
                                    <p><?php echo e($deliveryData->delivery_text); ?></p>
                                    <?php if(!empty($deliveryData->delivery_file)): ?>
                                        <a href="<?php echo e(route('download.job.delivery.file',str_replace('job-delivery-file/','',$deliveryData->delivery_file))); ?>"
                                           class="apply-now-button">
                                            <?php echo e(__('Download Delivery File')); ?>

                                            <i class="icon-material-outline-arrow-right-alt"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if($job->status == 'completed' && $rated == false): ?>
                    <!-- Sidebar Widget -->
                        <div class="sidebar-widget">
                            <div class="job-overview">
                                <div class="job-overview-headline bg-success text-white">
                                    <?php echo e(__('Give Service Provider Rating')); ?>

                                </div>
                                <div class="job-overview-inner">
                                    <form action="<?php echo e(route('save.job.feedback')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-xl-12">
                                                <div class="submit-field">
                                                    <h5 style="margin-bottom: 20px;"><?php echo e(__('Service Provider Rating')); ?></h5>
                                                    <select
                                                        class="star-rating <?php $__errorArgs = ['service_provider_rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                        required name="rating">
                                                        <option><?php echo e(__('Service Provider Rating')); ?></option>
                                                        <option value="5"><?php echo e(__('5 Star')); ?></option>
                                                        <option value="4"><?php echo e(__('4 Star')); ?></option>
                                                        <option value="3"><?php echo e(__('3 Star')); ?></option>
                                                        <option value="2"><?php echo e(__('2 Star')); ?></option>
                                                        <option value="1"><?php echo e(__('1 Star')); ?></option>
                                                    </select>
                                                    <?php $__errorArgs = ['service_provider_rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-xl-12">
                                                <div class="submit-field">
                                                    <h5><?php echo e(__('Feedback')); ?></h5>
                                                    <textarea cols="30" rows="5" class="with-border" name="feedback"
                                                              required></textarea>
                                                    <input type="hidden" name="job_id" value="<?php echo e(encrypt($job->id)); ?>">
                                                </div>
                                            </div>
                                            <div class="col-xl-12">
                                                <button class="button ripple-effect big margin-top-30" type="submit">
                                                    <i class="icon-feather-plus"></i>
                                                    <?php echo e(__('Submit')); ?>

                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($job->status == 'delivered' || $job->status == 'completed'): ?>
                        <?php if(!empty($deliveryData)): ?>
                            <div class="sidebar-widget">
                                <div class="job-overview">
                                    <div class="job-overview-headline">
                                        <?php echo e(__('Job Delivery Details')); ?>

                                    </div>
                                    <div class="job-overview-inner">
                                        <p><?php echo e($deliveryData->delivery_text); ?></p>
                                        <?php if(!empty($deliveryData->delivery_file)): ?>
                                            <a href="<?php echo e(route('download.job.delivery.file',str_replace('job-delivery-file/','',$deliveryData->delivery_file))); ?>"
                                               class="apply-now-button">
                                                <?php echo e(__('Download Delivery File')); ?>

                                                <i class="icon-material-outline-arrow-right-alt"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php if($job->status == 'completed'): ?>
                        <div class="sidebar-widget">
                            <div class="job-overview">
                                <div class="job-overview-headline">
                                    <?php echo e(__('Service Provider Feedback')); ?>

                                </div>
                                <div class="job-overview-inner">
                                    <?php if(empty($feedback)): ?>
                                        <?php echo e(__('No feedback given yet')); ?>

                                    <?php else: ?>
                                        <div class="star-rating" data-rating="<?php echo e($feedback->rating); ?>"></div>
                                        <p>
                                            <?php echo e($feedback->feedback); ?>

                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                <?php endif; ?>
                <!-- Sidebar Widget -->
                    <div class="sidebar-widget">
                        <div class="job-overview">
                            <div class="job-overview-headline">
                                <?php echo e(__('Job Summary')); ?>

                            </div>
                            <div class="job-overview-inner">
                                <ul>
                                    <li>
                                        <i class="icon-material-outline-location-on"></i>
                                        <span><?php echo e(__('Location')); ?></span>
                                        <h5>
                                            <?php echo e($job->jobCountry->name); ?>

                                        </h5>
                                    </li>
                                    <li>
                                        <i class="icon-material-outline-local-atm"></i>
                                        <span><?php echo e(__('Fee Range')); ?></span>
                                        <h5>$<?php echo e($job->fee_range_min); ?> -
                                            $<?php echo e($job->fee_range_max); ?></h5>
                                    </li>
                                    <li>
                                        <i class="icon-material-outline-access-time"></i>
                                        <span>
                                            <?php echo e(__('Date Posted')); ?>

                                        </span>
                                        <h5>
                                            <?php echo e($job->created_at->diffForHumans()); ?>

                                        </h5>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <div id="small-dialog" class="zoom-anim-dialog mfp-hide dialog-with-tabs">
        <!--Tabs -->
        <div class="sign-in-form">
            <ul class="popup-tabs-nav">
                <li>
                    <a href="#tab">
                        <?php echo e(__('Dispute')); ?>

                    </a>
                </li>
            </ul>
            <div class="popup-tabs-container">

                <!-- Tab -->
                <div class="popup-tab-content" id="tab">

                    <!-- Welcome Text -->
                    <div class="welcome-text">
                        <h3>
                            <?php echo e(__('Describe dispute reason')); ?>

                        </h3>
                    </div>

                    <!-- Form -->
                    <form method="post" id="apply-now-form" action="<?php echo e(route('dispute.job.delivery')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e(encrypt($job->id)); ?>">
                        <div class="input-with-icon-left">
                            <textarea name="reason"
                                      class="input-text with-border <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      cols="30" rows="10" required></textarea>
                            <?php $__errorArgs = ['reason'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- Button -->
                        <button class="button margin-top-35 full-width button-sliding-icon ripple-effect" type="submit"
                                form="apply-now-form"><?php echo e(__('Submit')); ?>

                            <i class="icon-material-outline-arrow-right-alt"></i>
                        </button>
                    </form>

                </div>

            </div>
        </div>
    </div>
    <div id="file-dialog" class="zoom-anim-dialog mfp-hide dialog-with-tabs">
        <!--Tabs -->
        <div class="sign-in-form">
            <div class="popup-tabs-container">
                <!-- Tab -->
                <div class="popup-tab-content" id="tab">
                    <form method="post" id="send-file-form" action="<?php echo e(route('apply-job')); ?>"
                          enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <!-- Welcome Text -->
                        <div class="welcome-text">
                            <input type="file" class="dropify chat-file" style="margin-top: 20px;" name="chat_file"
                                   required>
                        </div>
                        <button class="button margin-top-35 full-width button-sliding-icon ripple-effect" type="submit">
                            <?php echo e(__('Send')); ?>

                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/frontend')); ?>/vendor/rating/dist/star-rating.min.js"></script>
    <script src="<?php echo e(asset('assets/frontend/vendor/dropify/js/dropify.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.dropify').dropify();
        });
        var starratings = new StarRating('.star-rating', {
            onClick: function (el) {
                console.log('Selected: ' + el[el.selectedIndex].text);
            },
        });
    </script>

    <script>
        const db = firebase.database();
        const url = "job_chat_<?php echo e($jobId); ?>";

        <?php if(!empty($receiver->workerDetails->profile_pic)): ?>
        let receiver_photo = "<?php echo e(asset('profile/'.$receiver->workerDetails->profile_pic)); ?>";
        <?php else: ?>
        let receiver_photo = "<?php echo e(asset('assets/frontend')); ?>/images/user-avatar-placeholder.png";
        <?php endif; ?>

        <?php if(!empty(\Illuminate\Support\Facades\Auth::user()->profile_pic)): ?>
        let sender_photo = "<?php echo e(asset('profile/'.\Illuminate\Support\Facades\Auth::user()->profile_pic)); ?>";
        <?php else: ?>
        let sender_photo = "<?php echo e(asset('assets/frontend')); ?>/images/user-avatar-placeholder.png";
        <?php endif; ?>

        function postChat() {
            $.ajax({
                type: "GET",
                url: '<?php echo e(route('get.current.time')); ?>',
                success: function (data) {
                    let message = $('.message-data').val();
                    if (message != '') {
                        db.ref("messages/" + url).push().set({
                            "message": message,
                            "type": 'text',
                            "sender_id": <?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>,
                            "receiver_id": <?php echo e($receiver->workerDetails->id); ?>,
                            "date": data.date,
                            "time": data.time,
                        }, function (error) {
                            if (error) {
                                console.log(error);
                            } else {
                                $.ajax({
                                    type: "POST",
                                    url: '<?php echo e(route('chat.update.time')); ?>',
                                    data: {
                                        _token: '<?php echo e(csrf_token()); ?>',
                                        sender_id: <?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>,
                                        receiver_id: <?php echo e($receiver->workerDetails->id); ?>

                                    },
                                    success: function (data) {
                                        $('.message-data').val('');
                                        $('.contact-list').html(null);
                                        $('.contact-list').html(data);
                                    }
                                });
                            }
                        });
                    }
                }
            });
        }

        db.ref('messages/' + url).on("child_added", function (snapshot) {
            const url = "<?php echo e(asset('')); ?>/";
            const messages = snapshot.val();
            if (messages.sender_id == <?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>) {
                let type = messages.type;
                let chatMessage = '';
                if (type == 'text') {
                    chatMessage = `<p>` + messages.message + `</p>`;
                } else if (type == 'image') {
                    chatMessage = `<a href="` + `<?php echo e(url('download-message-file')); ?>` + '/' + messages.message.replace('chat-file/', '') + `"> <img src="` + url + messages.message + `" width="100"></a>`;
                } else {
                    chatMessage = `<a style="color:#ffffff;" href="` + `<?php echo e(url('download-message-file')); ?>` + '/' + messages.message.replace('chat-file/', '') + `">` + messages.message.replace('message/', '') + `</a>`;
                }
                const msg = `<div class="message-bubble me">
                            <div class="message-bubble-inner">
                                <div class="message-avatar"><img src="` + sender_photo + `" alt=""/>
                                </div>
                                <div class="message-text">` + chatMessage + `
                                    <p class="message-time">` + messages.date + ', ' + messages.time + `</p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>`;
                $('.message-content-inner').append(msg);
            } else {
                let type = messages.type;
                let chatMessage = '';
                if (type == 'text') {
                    chatMessage = `<p>` + messages.message + `</p>`;
                } else if (type == 'image') {
                    chatMessage = `<a href="` + `<?php echo e(url('download-message-file')); ?>` + '/' + messages.message.replace('chat-file/', '') + `"> <img src="` + url + messages.message + `" width="100"></a>`;
                } else {
                    chatMessage = `<a style="color:#000000;" href="` + `<?php echo e(url('download-message-file')); ?>` + '/' + messages.message.replace('chat-file/', '') + `">` + messages.message.replace('message/', '') + `</a>`;
                }
                const msg = `<div class="message-bubble">
                            <div class="message-bubble-inner">
                                <div class="message-avatar"><img src="` + receiver_photo + `" alt=""/>
                                </div>
                                <div class="message-text">` + chatMessage + `
                                    <p class="message-time">` + messages.date + ', ' + messages.time + `</p>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>`;
                $('.message-content-inner').append(msg);
            }
        });
    </script>

    <script>
        $(document).ready(function () {
            $('#send-file-form').on('submit', function (event) {
                event.preventDefault();
                $.ajax({
                    url: "<?php echo e(route('save.chat.file')); ?>",
                    method: "POST",
                    data: new FormData(this),
                    dataType: 'JSON',
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function (data) {
                        if (data.status == false) {
                            alert(data.error)
                        } else {
                            db.ref("messages/" + url).push().set({
                                "message": data.file_name,
                                "type": data.file_type,
                                "sender_id": <?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>,
                                "receiver_id": <?php echo e($receiver->workerDetails->id); ?>,
                                "date": data.date,
                                "time": data.time,
                            }, function (error) {
                                if (error) {
                                    console.log(error);
                                } else {
                                    $.ajax({
                                        type: "POST",
                                        url: '<?php echo e(route('chat.update.time')); ?>',
                                        data: {
                                            _token: '<?php echo e(csrf_token()); ?>',
                                            sender_id: <?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>,
                                            receiver_id: <?php echo e($receiver->workerDetails->id); ?>

                                        },
                                        success: function (data) {
                                            $('.message-data').val('');
                                            $('.contact-list').html(null);
                                            $('.contact-list').html(data);
                                            $('#send-file-form').trigger("reset");
                                            $('.mfp-close').trigger("click");
                                            $('.dropify-clear').trigger("click");
                                        }
                                    });
                                }
                            });
                        }
                    }
                })
            });

        });
    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/job/customer-manage.blade.php ENDPATH**/ ?>