<?php $__env->startSection('style'); ?>
    <!-- Data Tables -->
    <link rel="stylesheet" href="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.bs4.css"/>
    <link rel="stylesheet" href="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.bs4-custom.css"/>
    <link href="<?php echo e(admin_asset('')); ?>/vendor/datatables/buttons.bs.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    <?php echo e(__('Subscription Plans')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main container start -->
    <div class="main-container">

        <!-- Page header start -->
        <div class="page-header">

            <!-- Breadcrumb start -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><?php echo e(__('Subscription Plans')); ?></li>
            </ol>
            <!-- Breadcrumb end -->
            <div class="app-actions">
                <a href="<?php echo e(route('admin.subscription.plan.add')); ?>" class="btn active"><?php echo e(__('Add New')); ?></a>
            </div>
        </div>
        <!-- Page header end -->

        <!-- Row start -->
        <div class="row gutters">
            <div class="col-sm-12">
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <?php echo e(__('Subscription Plans')); ?>

                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="datatable table table-bordered">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th><?php echo e(__('Name')); ?></th>
                                    <th><?php echo e(__('Status')); ?></th>
                                    <th width="10%"><?php echo e(__('Action')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $sl = 0;
                                ?>
                                <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $sl++;
                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo e($sl); ?>

                                        </td>
                                        <td>
                                            <?php echo e($plan->title_en); ?>

                                        </td>
                                        <td>
                                            <?php if($plan->status == 'active'): ?>
                                                <span class="badge badge-success"><?php echo e(__('Active')); ?></span>
                                            <?php else: ?>
                                                <span class="badge badge-danger"><?php echo e(__('Inactive')); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <div class="dropdown">
                                                <button class="btn btn-primary dropdown-toggle" type="button"
                                                        id="dropdownMenuButton" data-toggle="dropdown"
                                                        aria-haspopup="true" aria-expanded="false">
                                                    <?php echo e(__('Actions')); ?>

                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                    <a class="dropdown-item"
                                                       href="<?php echo e(route('admin.subscription.plan.edit', $plan->id)); ?>"><?php echo e(__('Edit')); ?></a>
                                                    <a class="dropdown-item"
                                                       href="<?php echo e(route('admin.subscription.plan.delete', $plan->id)); ?>" onclick="return confirm('Are you sure?')"><?php echo e(__('Delete')); ?></a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->

    </div>
    <!-- Main container end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Data Tables -->
    <script src="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.min.js"></script>
    <script src="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.bootstrap.min.js"></script>
    <!-- Custom Data tables -->
    <script>
        $( document ).ready(function() {
            $('.datatable').dataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/admin/subscription-plan/index.blade.php ENDPATH**/ ?>