<?php $__env->startSection('title'); ?>
    <?php echo e(__('Messages')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Dashboard Container -->
    <div class="dashboard-container">
    <?php echo $__env->make('frontend.layouts.dashboard-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner">

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3>Messages</h3>

                    <!-- Breadcrumbs -->
                    <nav id="breadcrumbs" class="dark">
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                            <li><?php echo e(__('Messages')); ?></li>
                        </ul>
                    </nav>
                </div>

                <div class="messages-container margin-top-0">

                    <div class="messages-container-inner">

                        <!-- Messages -->
                        <div class="messages-inbox">
                            <div class="messages-headline">
                                <div class="input-with-icon">
                                    <input id="autocomplete-input" type="text" placeholder="Search">
                                    <i class="icon-material-outline-search"></i>
                                </div>
                            </div>

                            <ul>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="<?php if($contact->receiver->id == $receiver->receiver->id): ?> active-message <?php endif; ?>">
                                        <a href="<?php echo e(route('message',$contact->receiver->id)); ?>">
                                            <div class="message-avatar">
                                                
                                                <?php if(!empty($contact->receiver->profile_pic)): ?>
                                                    <img
                                                        src="<?php echo e(asset('public/profile/'.$contact->receiver->profile_pic)); ?>"
                                                        alt=""/>
                                                <?php else: ?>
                                                    <img
                                                        src="<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                        alt=""/>
                                                <?php endif; ?>
                                            </div>

                                            <div class="message-by">
                                                <div class="message-by-headline">
                                                    <h5><?php echo e($contact->receiver->first_name); ?> <?php echo e($contact->receiver->last_name); ?></h5>

                                                </div>

                                            </div>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Messages / End -->

                        <!-- Message Content -->
                        <div class="message-content">

                            <div class="messages-headline">
                                <h4><?php echo e($receiver->receiver->first_name); ?> <?php echo e($receiver->receiver->last_name); ?></h4>
                            </div>

                            <!-- Message Content Inner -->
                            <div class="message-content-inner"></div>
                            <!-- Message Content Inner / End -->

                            <!-- Reply Area -->
                            <div class="message-reply">
                                <textarea cols="1" rows="1" placeholder="Your Message" data-autoresize
                                          class="message-data"></textarea>





                                <button class="button ripple-effect" onclick="postChat();">Send</button>
                            </div>

                        </div>
                        <!-- Message Content -->

                    </div>
                </div>
                <!-- Messages Container / End -->

            </div>
        </div>
        <!-- Dashboard Content / End -->
    </div>
    <!-- Dashboard Container / End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        const db = firebase.database();
        const url = "<?php echo e($receiver->url); ?>";

        <?php if(!empty($receiver->receiver->profile_pic)): ?>
            let receiver_photo = "<?php echo e(asset('public/profile/'.$receiver->receiver->profile_pic)); ?>";
        <?php else: ?>
            let receiver_photo = "<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png";
        <?php endif; ?>

        <?php if(!empty(\Illuminate\Support\Facades\Auth::user()->profile_pic)): ?>
            let sender_photo = "<?php echo e(asset('public/profile/'.\Illuminate\Support\Facades\Auth::user()->profile_pic)); ?>";
        <?php else: ?>
            let sender_photo = "<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png";
        <?php endif; ?>

        function postChat() {
            let message = $('.message-data').val();
            db.ref("messages/" + url).push().set({
                "message": message,
                "type": 'text',
                "sender_id": <?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>,
                "receiver_id": <?php echo e($receiver->receiver_id); ?>

            }, function (error) {
                if (error) {
                    console.log(error);
                } else {
                    $('.message-data').val('');
                }
            });
        }

        db.ref('messages/' + url).on("child_added", function (snapshot) {
            const messages = snapshot.val();
            if (messages.sender_id == <?php echo e(\Illuminate\Support\Facades\Auth::id()); ?>) {
                const msg = `<div class="message-bubble me">
                            <div class="message-bubble-inner">
                                <div class="message-avatar"><img src="` + sender_photo + `" alt=""/>
                                </div>
                                <div class="message-text"><p>` + messages.message + `</p></div>
                            </div>
                            <div class="clearfix"></div>
                        </div>`;
                $('.message-content-inner').append(msg);
            } else {
                const msg = `<div class="message-bubble">
                            <div class="message-bubble-inner">
                                <div class="message-avatar"><img src="` + receiver_photo + `" alt=""/>
                                </div>
                                <div class="message-text"><p>` + messages.message + `</p></div>
                            </div>
                            <div class="clearfix"></div>
                        </div>`;
                $('.message-content-inner').append(msg);
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('public/assets/frontend/vendor/emoji/css/emojis.css')); ?>">
    <style>
        .message-reply{
            position: relative;
        }
        .message-picker{
            list-style: none;
            position: absolute;
            bottom: 10px;
            left: 0;
            margin: 0;
        }
        .message-picker li span{
            font-size: 20px !important;
            color: #f39c12;
            cursor: pointer;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/message/chat.blade.php ENDPATH**/ ?>