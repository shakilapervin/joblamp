<!doctype html>
<html lang="<?php echo e(session()->get('lang')?: 'en'); ?>">
<head>

    <!-- Basic Page Needs
    ================================================== -->
    <title><?php echo $__env->yieldContent('title','JobLamp'); ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/frontend')); ?>/css/colors/blue.css">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>

<!-- Wrapper -->
<div id="wrapper">

    <!-- Header Container
    ================================================== -->
    <header id="header-container" class="fullwidth">
        <!-- Header -->
        <div id="header">
            <div class="container">

                <!-- Left Side Content -->
                <div class="left-side">

                    <!-- Logo -->
                    <div id="logo">
                        <a href="<?php echo e(url('')); ?>">
                            <img src="<?php echo e(asset('assets/frontend')); ?>/images/joblamp.png" alt="">
                        </a>
                    </div>

                    <!-- Main Navigation -->
                    <nav id="navigation">
                        <ul id="responsive">
                            <li>
                                <a href="<?php echo e(route('home')); ?>" class="current"><?php echo e(__('Home')); ?></a>
                            </li>

                            <?php if(auth()->guard()->check()): ?>
                                <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'customer'): ?>
                                    <li>
                                        <a href="<?php echo e(route('job-post')); ?>"><?php echo e(__('Post a Job')); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('about.us')); ?>"><?php echo e(__('About Us')); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('contact.us')); ?>"><?php echo e(__('Contact Us')); ?></a>
                                    </li>
                                <?php else: ?>
                                    <li>
                                        <a href="<?php echo e(route('job-list')); ?>">
                                            <?php echo e(__('Find Work')); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('about.us')); ?>"><?php echo e(__('About Us')); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('contact.us')); ?>"><?php echo e(__('Contact Us')); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php else: ?>
                                <li>
                                    <a href="<?php echo e(route('job-list')); ?>">
                                        <?php echo e(__('Find Work')); ?>

                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('user-register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('user-login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('about.us')); ?>"><?php echo e(__('About Us')); ?></a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('contact.us')); ?>"><?php echo e(__('Contact Us')); ?></a>
                                </li>
                            <?php endif; ?>

                        </ul>
                    </nav>
                    <!-- Main Navigation End -->
                    <div class="header-search">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'customer'): ?>
                                <form action="<?php echo e(route('task-worker-list')); ?>" method="get">
                                    <div class="intro-banner-search-form">

                                        <!-- Search Field -->
                                        <div class="intro-search-field with-label">
                                            <input id="intro-keywords" type="text" placeholder="<?php echo e(__('Task worker name')); ?>"
                                                   name="keyword">
                                        </div>

                                        <!-- Button -->
                                        <div class="intro-search-button">
                                            <button class="button ripple-effect" type="submit"><?php echo e(__('Search')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            <?php else: ?>
                                <form action="<?php echo e(route('job-list')); ?>" method="get">
                                    <div class="intro-banner-search-form">

                                        <!-- Search Field -->
                                        <div class="intro-search-field with-label">
                                            <input id="intro-keywords" type="text" placeholder="<?php echo e(__('Job Title or Keywords')); ?>"
                                                   name="keyword">
                                        </div>

                                        <!-- Button -->
                                        <div class="intro-search-button">
                                            <button class="button ripple-effect" type="submit"><?php echo e(__('Search')); ?></button>
                                        </div>
                                    </div>
                                </form>
                            <?php endif; ?>
                        <?php else: ?>
                            <form action="<?php echo e(route('job-list')); ?>" method="get">
                                <div class="intro-banner-search-form">

                                    <!-- Search Field -->
                                    <div class="intro-search-field with-label">
                                        <input id="intro-keywords" type="text" placeholder="Job Title or Keywords"
                                               name="keyword">
                                    </div>

                                    <!-- Button -->
                                    <div class="intro-search-button">
                                        <button class="button ripple-effect" type="submit"><?php echo e(__('Search')); ?></button>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>

                    <div class="clearfix"></div>


                </div>
                <!-- Left Side Content / End -->


                <!-- Right Side Content / End -->
                <div class="right-side">
                <?php if(auth()->guard()->check()): ?>
                    <!--  User Notifications -->
                        <div class="header-widget hide-on-mobile">

                            <!-- Notifications -->
                            <div class="header-notifications">

                                <!-- Trigger -->
                                <div class="header-notifications-trigger">
                                    <a href="#">
                                        <i class="icon-feather-bell"></i>
                                        <span>4</span>
                                    </a>
                                </div>

                                <!-- Dropdown -->
                                <div class="header-notifications-dropdown">

                                    <div class="header-notifications-headline">
                                        <h4>Notifications</h4>
                                        <button class="mark-as-read ripple-effect-dark" title="Mark all as read"
                                                data-tippy-placement="left">
                                            <i class="icon-feather-check-square"></i>
                                        </button>
                                    </div>

                                    <div class="header-notifications-content">
                                        <div class="header-notifications-scroll" data-simplebar>
                                            <ul>
                                                <!-- Notification -->
                                                <li class="notifications-not-read">
                                                    <a href="dashboard-manage-candidates.html">
                                                    <span class="notification-icon"><i
                                                            class="icon-material-outline-group"></i></span>
                                                        <span class="notification-text">
													<strong>Michael Shannah</strong> applied for a job <span
                                                                class="color">Full Stack Software Engineer</span>
												</span>
                                                    </a>
                                                </li>

                                                <!-- Notification -->
                                                <li>
                                                    <a href="dashboard-manage-bidders.html">
                                                    <span class="notification-icon"><i
                                                            class=" icon-material-outline-gavel"></i></span>
                                                        <span class="notification-text">
													<strong>Gilbert Allanis</strong> placed a bid on your <span
                                                                class="color">iOS App Development</span> project
												</span>
                                                    </a>
                                                </li>

                                                <!-- Notification -->
                                                <li>
                                                    <a href="dashboard-manage-jobs.html">
                                                    <span class="notification-icon"><i
                                                            class="icon-material-outline-autorenew"></i></span>
                                                        <span class="notification-text">
													Your job listing <span class="color">Full Stack PHP Developer</span> is expiring.
												</span>
                                                    </a>
                                                </li>

                                                <!-- Notification -->
                                                <li>
                                                    <a href="dashboard-manage-candidates.html">
                                                        <span class="notification-icon">
                                                            <i class="icon-material-outline-group"></i>
                                                        </span>
                                                        <span class="notification-text">
                                                            <strong>Sindy Forrest</strong> applied for a job
                                                            <span class="color">
                                                                Full Stack Software Engineer
                                                            </span>
												        </span>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>

                                </div>

                            </div>

                        </div>
                        <!--  User Notifications / End -->

                        <!-- User Menu -->
                        <div class="header-widget">

                            <!-- Messages -->
                            <div class="header-notifications user-menu">
                                <div class="header-notifications-trigger">
                                    <a href="#">
                                        <div class="user-avatar status-online">
                                            <img
                                                src="<?php echo e(asset('assets/frontend')); ?>/images/user-avatar-small-01.jpg"
                                                alt="">
                                        </div>
                                    </a>
                                </div>

                                <!-- Dropdown -->
                                <div class="header-notifications-dropdown">

                                    <!-- User Status -->
                                    <div class="user-status">

                                        <!-- User Name / Avatar -->
                                        <div class="user-details">
                                            <div class="user-avatar status-online">
                                                <?php if(!empty(\Illuminate\Support\Facades\Auth::user()->profile_pic)): ?>
                                                    <img class="profile-pic"
                                                         src="<?php echo e(asset('profile')); ?>/<?php echo e(\Illuminate\Support\Facades\Auth::user()->profile_pic); ?>" alt=""/>
                                                <?php else: ?>
                                                    <img class="profile-pic"
                                                         src="<?php echo e(asset('assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                         alt=""/>
                                                <?php endif; ?>
                                            </div>
                                            <div class="user-name">
                                                <?php echo e(\Illuminate\Support\Facades\Auth::user()->first_name); ?> <?php echo e(\Illuminate\Support\Facades\Auth::user()->last_name); ?>

                                            </div>
                                        </div>

                                        <!-- User Status Switcher -->
                                        <div class="status-switch" id="snackbar-user-status">
                                            <label class="user-online current-status">Online</label>
                                            <label class="user-invisible">Invisible</label>
                                            <!-- Status Indicator -->
                                            <span class="status-indicator" aria-hidden="true"></span>
                                        </div>
                                    </div>

                                    <ul class="user-menu-small-nav">
                                        <li>
                                            <a href="<?php echo e(route('dashboard')); ?>">
                                                <i class="icon-material-outline-dashboard"></i>
                                                <?php echo e(__('Dashboard')); ?>

                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('edit.profile')); ?>">
                                                <i class="icon-material-outline-settings"></i>
                                                <?php echo e(__('Edit Profile')); ?>

                                            </a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('user-logout')); ?>">
                                                <i class="icon-material-outline-power-settings-new"></i>
                                                <?php echo e(__('Logout')); ?>

                                            </a>
                                        </li>
                                    </ul>

                                </div>
                            </div>

                        </div>
                        <!-- User Menu / End -->
                <?php endif; ?>
                <!-- Mobile Navigation Button -->
                    <span class="mmenu-trigger">
                            <button class="hamburger hamburger--collapse" type="button">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
				        </span>
                </div>
                <!-- Right Side Content / End -->

            </div>
        </div>
        <!-- Header End -->
    </header>
    <div class="clearfix"></div>
    <?php if(Route::is('home') || Route::is('job-list') || Route::is('job.details')): ?>
        <div class="job-category">
            <ul>
                <?php
                    $jobCategories = jobcategories();
                ?>
                <?php $__currentLoopData = $jobCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('job-list')); ?>/?category_id=<?php echo e($jobCategory->id); ?>">
                            <?php echo e($jobCategory->name); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<!-- Header Container End -->
<?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>