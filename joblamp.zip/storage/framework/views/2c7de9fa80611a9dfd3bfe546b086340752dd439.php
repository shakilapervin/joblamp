<?php $__env->startSection('title'); ?>
    <?php echo e(__('Edit Profile')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Dashboard Container -->
    <div class="dashboard-container">
    <?php echo $__env->make('frontend.layouts.dashboard-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner">

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3>Edit Profile</h3>

                    <!-- Breadcrumbs -->
                    <nav id="breadcrumbs" class="dark">
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                            <li><?php echo e(__('Edit Profile')); ?></li>
                        </ul>
                    </nav>
                </div>
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('update.profile')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- Row -->
                    <div class="row">

                        <!-- Dashboard Box -->
                        <div class="col-xl-12">
                            <div class="dashboard-box margin-top-0">


                                <!-- Headline -->
                                <div class="headline">
                                    <h3>
                                        <i class="icon-material-outline-account-circle"></i> <?php echo e(__('General Information')); ?>

                                    </h3>
                                </div>

                                <div class="content with-padding padding-bottom-0">

                                    <div class="row">

                                        <div class="col-auto">
                                            <div class="avatar-wrapper" data-tippy-placement="bottom"
                                                 title="Change Avatar">
                                                <?php if(!empty($user->profile_pic)): ?>
                                                    <img class="profile-pic"
                                                         src="<?php echo e(asset('public/profile')); ?>/<?php echo e($user->profile_pic); ?>" alt=""/>
                                                <?php else: ?>
                                                    <img class="profile-pic"
                                                         src="<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                         alt=""/>
                                                <?php endif; ?>
                                                <div class="upload-button"></div>
                                                <input class="file-upload" type="file" accept="image/*"
                                                       name="profile_pic"/>
                                            </div>
                                        </div>

                                        <div class="col">
                                            <div class="row">
                                                <div class="col-xl-6">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('First Name')); ?></h5>
                                                        <input name="first_name" type="text"
                                                               class="with-border <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               value="<?php echo e($user->first_name); ?>">
                                                        <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                <div class="col-xl-6">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('Last Name')); ?></h5>
                                                        <input name="last_name" type="text"
                                                               class="with-border <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               value="<?php echo e($user->last_name); ?>">
                                                        <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                <div class="col-xl-6">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('Email Address')); ?></h5>
                                                        <input name="email" type="text"
                                                               class="with-border <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               value="<?php echo e($user->email); ?>">
                                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <div class="col-xl-6">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('Pin Code')); ?></h5>
                                                        <input name="pincode" type="text"
                                                               class="with-border <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               value="<?php echo e($user->pincode); ?>">
                                                        <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                <div class="col-xl-6">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('Mobile Number')); ?></h5>
                                                        <input name="mobile_number" type="text"
                                                               class="with-border <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               value="<?php echo e($user->mobile_number); ?>">
                                                        <?php $__errorArgs = ['mobile_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>

                        <!-- Dashboard Box -->
                        <div class="col-xl-12">
                            <div class="dashboard-box">

                                <!-- Headline -->
                                <div class="headline">
                                    <h3><i class="icon-line-awesome-map"></i> Address</h3>
                                </div>

                                <div class="content">
                                    <ul class="fields-ul">
                                        <li>
                                            <div class="row">
                                                <div class="col-xl-6">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('Address Line 1')); ?></h5>
                                                        <input name="address_line_1" type="text"
                                                               class="with-border <?php $__errorArgs = ['address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               value="<?php echo e($user->address_line_1); ?>" required>
                                                        <?php $__errorArgs = ['address_line_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                <div class="col-xl-6">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('Address Line 2')); ?></h5>
                                                        <input name="address_line_2" type="text"
                                                               class="with-border <?php $__errorArgs = ['address_line_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                               value="<?php echo e($user->address_line_2); ?>">
                                                        <?php $__errorArgs = ['address_line_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>

                                                <div class="col-xl-6">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('Country')); ?></h5>
                                                        <select id="country"
                                                            class="selectpicker with-border <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            data-size="7" title="Select Country" data-live-search="true"
                                                            name="country" onchange="getStates();" required>
                                                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($country->id); ?>"
                                                                        <?php if($country->id == $user->country): ?> selected <?php endif; ?>><?php echo e($country->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xl-6 state">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('State')); ?></h5>
                                                        <select
                                                                class="selectpicker with-border <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                data-size="7" title="Select State"
                                                                data-live-search="true" name="state" onchange="getCities()" required>
                                                            <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($state->id); ?>"
                                                                        <?php if($state->id == $user->state): ?> selected <?php endif; ?>><?php echo e($state->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>

                                                <div class="col-xl-6 city">
                                                    <div class="submit-field">
                                                        <h5><?php echo e(__('City')); ?></h5>
                                                        <select id="city"
                                                            class="selectpicker with-border <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                            data-size="7" title="Select City" data-live-search="true"
                                                            name="city" required>
                                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($city->id); ?>"
                                                                        <?php if($city->id == $user->city): ?> selected <?php endif; ?>><?php echo e($city->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>

                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'service_provider'): ?>
                                <div class="col-xl-12">
                                    <div class="dashboard-box">

                                        <!-- Headline -->
                                        <div class="headline">
                                            <h3><i class="icon-line-awesome-bookmark"></i> Skills</h3>
                                        </div>

                                        <div class="content">
                                            <ul class="fields-ul">
                                                <li>
                                                    <div class="row">
                                                        <div class="col-xl-12">
                                                            <div class="submit-field">
                                                                <h5><?php echo e(__('Choose Your Skills')); ?></h5>
                                                                <select id="city"
                                                                        class="selectpicker with-border <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-size="10" title="Select Your Skills" data-live-search="true" name="skills[]" multiple>
                                                                    <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($skill->id); ?>"
                                                                        <?php if ( $user->skill != null and in_array($skill->id, json_decode($user->skill))) echo 'selected'?>><?php echo e($skill->name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <!-- Dashboard Box -->
                                <div class="col-xl-12">
                                    <div class="dashboard-box">

                                        <!-- Headline -->
                                        <div class="headline">
                                            <h3><i class="icon-line-awesome-book"></i> Documents</h3>
                                        </div>

                                        <div class="content">
                                            <ul class="fields-ul">
                                                <li>
                                                    <div class="row">
                                                        <div class="col-xl-4">
                                                            <div class="submit-field">
                                                                <div class="submit-field">
                                                                    <h5><?php echo e(__('Document 1')); ?></h5>
                                                                    <?php if(!empty($user->doc_1)): ?>
                                                                    <!-- Attachments -->
                                                                    <div class="attachments-container margin-top-0 margin-bottom-0">
                                                                        <div class="attachment-box ripple-effect">
                                                                            <span><?php echo e(__('Document 1')); ?></span>
                                                                            <button type="button" class="remove-attachment" data-tippy-placement="top" data-tippy="" data-original-title="Remove" onclick="removeDoc(<?php echo e($user->id); ?>,1);"></button>
                                                                        </div>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    <div class="clearfix"></div>
                                                                    <!-- Upload Button -->
                                                                    <div class="uploadButton margin-top-0">
                                                                        <input class="uploadButton-input" type="file" accept="image/*, application/pdf" id="doc_1" name="doc_1">
                                                                        <label class="uploadButton-button ripple-effect" for="doc_1">
                                                                            <?php echo e(__('Upload Files')); ?>

                                                                        </label>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-xl-4">
                                                            <div class="submit-field">
                                                                <div class="submit-field">
                                                                    <h5><?php echo e(__('Document 2')); ?></h5>
                                                                    <?php if(!empty($user->doc_2)): ?>
                                                                    <!-- Attachments -->
                                                                    <div class="attachments-container margin-top-0 margin-bottom-0">
                                                                        <div class="attachment-box ripple-effect">
                                                                            <span><?php echo e(__('Document 2')); ?></span>
                                                                            <button type="button" class="remove-attachment" data-tippy-placement="top" data-tippy="" data-original-title="Remove" onclick="removeDoc(<?php echo e($user->id); ?>,2);"></button>
                                                                        </div>
                                                                    </div>
                                                                    <?php endif; ?>
                                                                    <div class="clearfix"></div>
                                                                    <!-- Upload Button -->
                                                                    <div class="uploadButton margin-top-0">
                                                                        <input class="uploadButton-input" type="file" accept="image/*, application/pdf" id="doc_2" name="doc_2">
                                                                        <label class="uploadButton-button ripple-effect" for="doc_2">
                                                                            <?php echo e(__('Upload Files')); ?>

                                                                        </label>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-xl-4">
                                                            <div class="submit-field">
                                                                <div class="submit-field">
                                                                    <h5><?php echo e(__('Document 3')); ?></h5>
                                                                <?php if(!empty($user->doc_3)): ?>
                                                                    <!-- Attachments -->
                                                                        <div class="attachments-container margin-top-0 margin-bottom-0">
                                                                            <div class="attachment-box ripple-effect">
                                                                                <span><?php echo e(__('Document 3')); ?></span>
                                                                                <button type="button" class="remove-attachment" data-tippy-placement="top" data-tippy="" data-original-title="Remove" onclick="removeDoc(<?php echo e($user->id); ?>,3);"></button>
                                                                            </div>
                                                                        </div>
                                                                    <?php endif; ?>
                                                                    <div class="clearfix"></div>
                                                                    <!-- Upload Button -->
                                                                    <div class="uploadButton margin-top-0">
                                                                        <input class="uploadButton-input" type="file" accept="image/*, application/pdf" id="doc_3" name="doc_3">
                                                                        <label class="uploadButton-button ripple-effect" for="doc_3">
                                                                            <?php echo e(__('Upload Files')); ?>

                                                                        </label>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>
                        <!-- Button -->
                        <div class="col-xl-12">
                            <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                            <button type="submit" class="button ripple-effect big margin-top-30">Save Changes</button>
                        </div>

                    </div>
                    <!-- Row / End -->
                </form>
                <!-- Footer -->
                <div class="dashboard-footer-spacer"></div>

            </div>
        </div>
        <!-- Dashboard Content / End -->

    </div>
    <!-- Dashboard Container / End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        function getStates() {
            var country = $('select#country').val();
            $.ajax({
                type: "POST",
                url: '<?php echo e(route('get.states')); ?>',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    country: country
                },
                success: function (data) {
                    console.log(data);
                    $('.state').html(null);
                    $('.state').html(data);
                    getCities();
                }
            });
        }

        function getCities() {
            var state = $('select#state').val();
            var country = $('select#country').val();
            $.ajax({
                type: "POST",
                url: '<?php echo e(route('get.cities')); ?>',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    state: state,
                    country: country,
                },
                success: function (data) {
                    console.log(data);
                    $('.city').html(null);
                    $('.city').html(data);
                }
            });
        }
        function removeDoc(user_id,doc) {
            $.ajax({
                type: "POST",
                url: '<?php echo e(route('remove.doc')); ?>',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    user_id: user_id,
                    doc: doc,
                },
                success: function (data) {
                    location.reload();
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/profile/edit-profile.blade.php ENDPATH**/ ?>