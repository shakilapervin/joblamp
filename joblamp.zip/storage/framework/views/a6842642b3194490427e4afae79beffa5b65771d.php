<?php $__env->startSection('title'); ?>
    <?php echo e(__('Edit Subscription Plan')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main container start -->
    <div class="main-container">

        <!-- Page header start -->
        <div class="page-header">
            <!-- Breadcrumb start -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><?php echo e(__('Edit Subscription Plan')); ?></li>
            </ol>
            <!-- Breadcrumb end -->

            <!-- App actions start -->
            <div class="app-actions">
                <a href="<?php echo e(route('admin.subscription.plans')); ?>"
                   class="btn active"><?php echo e(__('All Subscription Plans')); ?></a>
            </div>
            <!-- App actions end -->

        </div>
        <!-- Page header end -->

        <!-- Row start -->
        <div class="row gutters">
            <form class="col-md-12" action="<?php echo e(route('admin.subscription.plan.update')); ?>" method="post"
                  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header">
                        <div class="row">
                            <?php if(Session::has('error')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert"
                                     style="width: 100%;">
                                    <?php echo e(Session::get('error')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert"
                                     style="width: 100%;">
                                    <?php echo e(Session::get('success')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="card-title"><?php echo e(__('Plan Information')); ?></div>
                    </div>
                    <div class="card-body">
                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Title English')); ?></label>
                            <div class="col-sm-4">
                                <input type="text"
                                       class="form-control form-control <?php $__errorArgs = ['title_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="colFormLabelSm" name="title_en"
                                       required
                                       value="<?php echo e($plan->title_en); ?>">
                                <?php $__errorArgs = ['title_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Description English')); ?></label>
                            <div class="col-md-4">
                                <textarea name="description_en"
                                          class="form-control <?php $__errorArgs = ['description_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30"
                                          rows="10" required><?php echo e($plan->description_en); ?></textarea>
                                <?php $__errorArgs = ['description_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Title Spanish')); ?></label>
                            <div class="col-sm-4">
                                <input type="text"
                                       class="form-control form-control <?php $__errorArgs = ['title_es'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="colFormLabelSm" name="title_es"
                                       required
                                       value="<?php echo e($plan->title_es); ?>">
                                <?php $__errorArgs = ['title_es'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Description English')); ?></label>
                            <div class="col-md-4">
                                <textarea name="description_es"
                                          class="form-control <?php $__errorArgs = ['description_es'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30"
                                          rows="10" required><?php echo e($plan->description_es); ?></textarea>
                                <?php $__errorArgs = ['description_es'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Title German')); ?></label>
                            <div class="col-sm-4">
                                <input type="text"
                                       class="form-control form-control <?php $__errorArgs = ['title_de'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="colFormLabelSm" name="title_de"
                                       required
                                       value="<?php echo e($plan->title_de); ?>">
                                <?php $__errorArgs = ['title_de'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Description German')); ?></label>
                            <div class="col-md-4">
                                <textarea name="description_de"
                                          class="form-control <?php $__errorArgs = ['description_de'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30"
                                          rows="10" required><?php echo e($plan->description_de); ?></textarea>
                                <?php $__errorArgs = ['description_de'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Title French')); ?></label>
                            <div class="col-sm-4">
                                <input type="text"
                                       class="form-control form-control <?php $__errorArgs = ['title_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="colFormLabelSm" name="title_fr"
                                       required
                                       value="<?php echo e($plan->title_fr); ?>">
                                <?php $__errorArgs = ['title_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Description French')); ?></label>
                            <div class="col-md-4">
                                <textarea name="description_fr"
                                          class="form-control <?php $__errorArgs = ['description_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30"
                                          rows="10" required><?php echo e($plan->description_fr); ?></textarea>
                                <?php $__errorArgs = ['description_fr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Title Romania')); ?></label>
                            <div class="col-sm-4">
                                <input type="text"
                                       class="form-control form-control <?php $__errorArgs = ['title_ro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="colFormLabelSm" name="title_ro"
                                       required
                                       value="<?php echo e($plan->title_ro); ?>">
                                <?php $__errorArgs = ['title_ro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Description Romania')); ?></label>
                            <div class="col-md-4">
                                <textarea name="description_ro"
                                          class="form-control <?php $__errorArgs = ['description_ro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30"
                                          rows="10" required><?php echo e($plan->description_ro); ?></textarea>
                                <?php $__errorArgs = ['description_ro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Title Portuguese')); ?></label>
                            <div class="col-sm-4">
                                <input type="text"
                                       class="form-control form-control <?php $__errorArgs = ['title_pt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="colFormLabelSm" name="title_pt"
                                       required
                                       value="<?php echo e($plan->title_pt); ?>">
                                <?php $__errorArgs = ['title_pt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <label for="colFormLabelSm"
                                   class="col-md-2 col-form-label"><?php echo e(__('Description Portuguese')); ?></label>
                            <div class="col-md-4">
                                <textarea name="description_pt"
                                          class="form-control <?php $__errorArgs = ['description_pt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30"
                                          rows="10" required><?php echo e($plan->description_pt); ?></textarea>
                                <?php $__errorArgs = ['description_pt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-sm-12 col-form-label"><?php echo e(__('Default Price')); ?></label>
                            <div class="col-sm-12">
                                <input type="text"
                                       class="form-control <?php $__errorArgs = ['default_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="colFormLabelSm" placeholder="<?php echo e(__('Plan default price')); ?>"
                                       name="default_price"
                                       required
                                       value="<?php echo e($plan->default_price); ?>">
                                <?php $__errorArgs = ['default_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="recommended"
                                   class="col-sm-12 col-form-label"><?php echo e(__('Recommended')); ?></label>
                            <div class="col-sm-12">
                                <select name="recommended" id="recommended" class="form-control">
                                    <option value="1"
                                            <?php if($plan->recommended == '1'): ?> selected <?php endif; ?>><?php echo e(__('Yes')); ?></option>
                                    <option value="0"
                                            <?php if($plan->recommended == '0'): ?> selected <?php endif; ?>><?php echo e(__('No')); ?></option>
                                </select>
                                <?php $__errorArgs = ['recommended'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-sm-12 col-form-label"><?php echo e(__('Numbers of Job Can Apply')); ?></label>
                            <div class="col-sm-12">
                                <input type="text"
                                       class="form-control <?php $__errorArgs = ['number_of_jobs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="colFormLabelSm"
                                       name="number_of_jobs"
                                       required
                                       value="<?php echo e($plan->number_of_jobs); ?>">
                                <?php $__errorArgs = ['number_of_jobs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-sm-12 col-form-label"><?php echo e(__('Plan Pricing')); ?></label>
                        </div>
                        <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group row">
                                <div class="col-sm-2">
                                    <input type="text"
                                           class="form-control"
                                           id="colFormLabelSm"
                                           readonly
                                           value="<?php echo e($price->country->name); ?>">
                                    <input type="hidden" name="country_id[]" value="<?php echo e($price->country_id); ?>">
                                </div>
                                <div class="col-sm-4">
                                    <input type="text"
                                           class="form-control form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="colFormLabelSm" name="price[]"
                                           required
                                           value="<?php echo e($price->price); ?>">
                                    <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-sm-12 col-form-label"><?php echo e(__('Plan Features')); ?></label>
                        </div>
                        <div class="feature-list">
                            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group row">
                                        <label for="colFormLabelSm"
                                               class="col-sm-2 col-form-label"><?php echo e(__('Feature English')); ?></label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" id="colFormLabelSm"
                                                   name="feature_en[]" value="<?php echo e($feature->content_en); ?>" required>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabelSm"
                                               class="col-sm-2 col-form-label"><?php echo e(__('Feature Spanish')); ?></label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" id="colFormLabelSm"
                                                   name="feature_es[]" value="<?php echo e($feature->content_es); ?>" required>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabelSm"
                                               class="col-sm-2 col-form-label"><?php echo e(__('Feature German')); ?></label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" id="colFormLabelSm"
                                                   name="feature_de[]" value="<?php echo e($feature->content_de); ?>" required>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabelSm"
                                               class="col-sm-2 col-form-label"><?php echo e(__('Feature French')); ?></label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" id="colFormLabelSm"
                                                   name="feature_fr[]" value="<?php echo e($feature->content_fr); ?>" required>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabelSm"
                                               class="col-sm-2 col-form-label"><?php echo e(__('Feature Romania')); ?></label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" id="colFormLabelSm"
                                                   name="feature_ro[]" value="<?php echo e($feature->content_ro); ?>" required>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="colFormLabelSm"
                                               class="col-sm-2 col-form-label"><?php echo e(__('Feature Portuguese')); ?></label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" id="colFormLabelSm"
                                                   name="feature_pt[]" value="<?php echo e($feature->content_pt); ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn btn-danger btn-lg"
                                            onclick="removeFeature(this);"><?php echo e(__('Remove Feature')); ?></button>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <button type="button" class="btn btn-success my-1 btn-lg" onclick="addFeature();"><?php echo e(__('Add Feature')); ?></button>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="colFormLabelSm"
                                   class="col-sm-12 col-form-label"><?php echo e(__('Status')); ?></label>
                            <div class="col-sm-12">
                                <select name="status" id="status" class="form-control">
                                    <option value="active"
                                            <?php if($plan->status == 'active'): ?> selected <?php endif; ?>><?php echo e(__('Active')); ?></option>
                                    <option value="inactive"
                                            <?php if($plan->status == 'inactive'): ?> selected <?php endif; ?>><?php echo e(__('Inactive')); ?></option>
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer">
                        <div class="form-group row">
                            <div class="col-md-12">
                                <input type="hidden" name="id" value="<?php echo e($plan->id); ?>">
                                <button type="submit" class="btn btn-primary my-1 btn-lg"><?php echo e(__('Update')); ?></button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <!-- Row end -->

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(admin_asset('/vendor/select2/dist/js/select2.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            $('.select2').select2();
        });
        function addFeature(){
            var html = `<div class="row">
                            <div class="col-md-8">
                                <div class="form-group row">
                                    <label for="colFormLabelSm"
                                           class="col-sm-2 col-form-label"><?php echo e(__('Feature English')); ?></label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="colFormLabelSm" name="feature_en[]" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="colFormLabelSm"
                                           class="col-sm-2 col-form-label"><?php echo e(__('Feature Spanish')); ?></label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="colFormLabelSm" name="feature_es[]" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="colFormLabelSm"
                                           class="col-sm-2 col-form-label"><?php echo e(__('Feature German')); ?></label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="colFormLabelSm" name="feature_de[]" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="colFormLabelSm"
                                           class="col-sm-2 col-form-label"><?php echo e(__('Feature French')); ?></label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="colFormLabelSm" name="feature_fr[]" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="colFormLabelSm"
                                           class="col-sm-2 col-form-label"><?php echo e(__('Feature Romania')); ?></label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="colFormLabelSm" name="feature_ro[]" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="colFormLabelSm"
                                           class="col-sm-2 col-form-label"><?php echo e(__('Feature Portuguese')); ?></label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="colFormLabelSm" name="feature_pt[]" required>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-danger btn-lg" onclick="removeFeature(this);"><?php echo e(__('Remove Feature')); ?></button>
                            </div>
                        </div>`;
            $('.feature-list').append(html);
        }
        function removeFeature(){
            $(event.currentTarget).closest('.row').remove();
        }
    </script>
    <script>
        function getStates() {
            var country = $('select#country').val();
            $.ajax({
                type: "POST",
                url: '<?php echo e(route('admin.get.states')); ?>',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    country: country
                },
                success: function (data) {
                    console.log(data);
                    $('.state').html(null);
                    $('.state').html(data);
                    getCities();
                }
            });
        }

        function getCities() {
            var state = $('select#state').val();
            var country = $('select#country').val();
            $.ajax({
                type: "POST",
                url: '<?php echo e(route('admin.get.cities')); ?>',
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    state: state,
                    country: country,
                },
                success: function (data) {
                    console.log(data);
                    $('.city').html(null);
                    $('.city').html(data);
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/admin/subscription-plan/edit.blade.php ENDPATH**/ ?>