<?php $__env->startSection('content'); ?>
    <style>
        a {
            color: #bcd0f7 !important;
        }
    </style>
    <!-- Main container start -->
    <div class="main-container">

        <!-- Page header start -->
        <div class="page-header">

            <!-- Breadcrumb start -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><?php echo e(__('Welcome')); ?>

                    , <?php echo e(\Illuminate\Support\Facades\Auth::user()->first_name); ?> <?php echo e(\Illuminate\Support\Facades\Auth::user()->last_name); ?></li>
            </ol>
            <!-- Breadcrumb end -->

        </div>
        <!-- Page header end -->


        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-6">
                <a href="<?php echo e(route('admin.contractors')); ?>">
                    <div class="social-tile h-165">
                        <div class="social-icon bg-info">
                            <i class="icon-users"></i>
                        </div>
                        <div><?php echo e(__('Total Service Providers')); ?></div>
                        <h2 class="text-grey">
                            <?php echo e(number_format(\App\User::where('user_type','service_provider')->count(),0,'.',',')); ?>

                        </h2>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-6">
                <a href="<?php echo e(route('admin.customers')); ?>">
                    <div class="social-tile h-165">
                        <div class="social-icon bg-danger">
                            <i class="icon-user1"></i>
                        </div>
                        <div><?php echo e(__('Total Customers')); ?></div>
                        <h2 class="text-grey">
                            <?php echo e(number_format(\App\User::where('user_type','customer')->count(),0,'.',',')); ?>

                        </h2>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-6">
                <a href="<?php echo e(route('admin.jobs')); ?>">
                    <div class="social-tile h-165">
                        <div class="social-icon bg-success">
                            <i class="icon-shopping-bag1"></i>
                        </div>
                        <div><?php echo e(__('Active Job')); ?></div>
                        <h2 class="text-grey">
                            <?php echo e(number_format(\App\Job::where('status','opened')->count(),0,'.',',')); ?>

                        </h2>
                    </div>
                </a>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-4 col-6">
                <a href="<?php echo e(route('admin.jobs')); ?>">
                    <div class="social-tile h-165">
                        <div class="social-icon bg-warning">
                            <i class="icon-shopping-bag1"></i>
                        </div>
                        <div><?php echo e(__('Completed Jobs')); ?></div>
                        <h2 class="text-grey">
                            <?php echo e(number_format(\App\Job::where('status','completed')->count(),0,'.',',')); ?>

                        </h2>
                    </div>
                </a>
            </div>
        </div>
        <!-- Row end -->


    </div>
    <!-- Main container end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/admin/dashboard/dashboard.blade.php ENDPATH**/ ?>