<?php $__env->startSection('title'); ?>
    <?php echo e(__('Withdraw')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Dashboard Container -->
    <div class="dashboard-container">
    <?php echo $__env->make('frontend.layouts.dashboard-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner">

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3><?php echo e(__('Withdraw')); ?></h3>

                    <!-- Breadcrumbs -->
                    <nav id="breadcrumbs" class="dark">
                        <ul>
                            <li>
                                <a href="<?php echo e(url('')); ?>"><?php echo e(__('Home')); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                            </li>
                            <li><?php echo e(__('Withdraw')); ?></li>
                        </ul>
                    </nav>
                </div>

                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
            <?php endif; ?>

            <!-- Row -->
                <div class="row">

                    <!-- Dashboard Box -->
                    <div class="col-xl-12">
                        <div class="dashboard-box margin-top-0">

                            <!-- Headline -->
                            <div class="headline">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link active" id="method-tab" data-toggle="tab" href="#bank"
                                           role="tab"><?php echo e(__('Bank Details')); ?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="paypal-tab" data-toggle="tab" href="#paypal"
                                           role="tab"><?php echo e(__('Paypal Details')); ?></a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" id="withdraw-tab" data-toggle="tab" href="#withdraw-request"
                                           role="tab"><?php echo e(__('Withdraw')); ?></a>
                                    </li>
                                </ul>
                            </div>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="bank" role="tabpanel">
                                    <form action="<?php echo e(route('update.withdraw.method')); ?>" method="post"
                                          enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                        <input type="hidden" name="type" value="stripe">
                                    <!-- Row -->
                                        <div class="row">

                                            <!-- Dashboard Box -->
                                            <div class="col-xl-12">
                                                <div class="dashboard-box margin-top-0">
                                                    <!-- Headline -->
                                                    <div class="headline">
                                                        <h3>
                                                            <i class="icon-line-awesome-bank"></i>
                                                            <?php echo e(__('Bank Information')); ?>

                                                        </h3>
                                                    </div>

                                                    <div class="content with-padding padding-bottom-0">

                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="row">
                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Country')); ?></h5>
                                                                            <select id="country"
                                                                                    class="selectpicker with-border <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    data-size="7" title="Select Country"
                                                                                    data-live-search="true"
                                                                                    name="country"
                                                                                    onchange="getStates();">
                                                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option
                                                                                        value="<?php echo e($country['cca2']); ?>"
                                                                                    <?php if(!empty($bank)): ?>
                                                                                        <?php if($bank->country == $country['cca2']): ?>
                                                                                            selected

                                                                                        <?php endif; ?>
                                                                                    <?php endif; ?>
                                                                                    >
                                                                                        <?php echo e($country['name']['common']); ?>

                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                            <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Currency')); ?></h5>
                                                                            <select id="currency"
                                                                                    class="selectpicker with-border <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    data-size="7" title="Select Currency"
                                                                                    data-live-search="true"
                                                                                    name="currency">
                                                                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option
                                                                                        value="<?php echo e($key); ?>"
                                                                                        <?php if(!empty($bank)): ?>
                                                                                            <?php if(strtoupper($bank->currency) == $key): ?> selected <?php endif; ?>
                                                                                        <?php endif; ?>
                                                                                    >
                                                                                        <?php echo e($key); ?>

                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                            <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Account Holder Name')); ?></h5>
                                                                            <input name="account_holder_name"
                                                                                   type="text"
                                                                                   class="with-border <?php $__errorArgs = ['account_holder_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                   value="<?php if(!empty($bank->account_holder_name)): ?> <?php echo e($bank->account_holder_name); ?> <?php endif; ?>">
                                                                            <?php $__errorArgs = ['account_holder_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>

                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Routing Number')); ?></h5>
                                                                            <input name="routing_number"
                                                                                   type="text"
                                                                                   class="with-border <?php $__errorArgs = ['routing_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                   value="<?php if(!empty($bank->routing_number)): ?> <?php echo e($bank->routing_number); ?> <?php endif; ?>">
                                                                            <?php $__errorArgs = ['routing_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Account Number')); ?></h5>
                                                                            <input name="account_number"
                                                                                   type="text"
                                                                                   class="with-border <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                   value="<?php if(!empty($bank->account_number)): ?> <?php echo e($bank->account_number); ?> <?php endif; ?>">
                                                                            <?php $__errorArgs = ['account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Account Type')); ?></h5>
                                                                            <select id="account_holder_type"
                                                                                    class="selectpicker with-border <?php $__errorArgs = ['account_holder_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    data-size="7"
                                                                                    title="Select Account Type"
                                                                                    data-live-search="true"
                                                                                    name="account_holder_type">
                                                                                <option value="">
                                                                                    <?php echo e(__('Select Account Type')); ?>

                                                                                </option>
                                                                                <option value="individual"
                                                                                <?php if(!empty($bank)): ?>
                                                                                    <?php if($bank->account_holder_type == 'individual'): ?> selected <?php endif; ?>
                                                                                <?php endif; ?>
                                                                                >
                                                                                    <?php echo e(__('Individual')); ?>

                                                                                </option>
                                                                                <option value="company"
                                                                                    <?php if(!empty($bank)): ?>
                                                                                        <?php if($bank->account_holder_type == 'company'): ?> selected <?php endif; ?>
                                                                                    <?php endif; ?>
                                                                                >
                                                                                    <?php echo e(__('Company')); ?>

                                                                                </option>
                                                                            </select>
                                                                            <?php $__errorArgs = ['account_holder_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Dashboard Box -->
                                            <div class="col-xl-12">
                                                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                                <button type="submit" class="button ripple-effect big margin-top-30">
                                                    Save Changes
                                                </button>
                                            </div>

                                        </div>
                                        <!-- Row / End -->
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="paypal" role="tabpanel">
                                    <form action="<?php echo e(route('update.withdraw.method')); ?>" method="post"
                                          enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <!-- Row -->
                                        <div class="row">

                                            <!-- Dashboard Box -->
                                            <div class="col-xl-12">
                                                <div class="dashboard-box margin-top-0">
                                                    <!-- Headline -->
                                                    <div class="headline">
                                                        <h3>
                                                            <i class="icon-line-awesome-bank"></i>
                                                            <?php echo e(__('Paypal Information')); ?>

                                                        </h3>
                                                    </div>

                                                    <div class="content with-padding padding-bottom-0">

                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="row">
                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Paypal Account Email Address')); ?></h5>
                                                                            <input name="paypal_email"
                                                                                   type="text"
                                                                                   class="with-border <?php $__errorArgs = ['paypal_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                   value="<?php if(!empty($bank->account_number)): ?> <?php echo e($bank->account_number); ?> <?php endif; ?>">
                                                                            <?php $__errorArgs = ['paypal_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Currency')); ?></h5>
                                                                            <select id="currency"
                                                                                    class="selectpicker with-border <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    data-size="7" title="Select Currency"
                                                                                    data-live-search="true"
                                                                                    name="currency">
                                                                                <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <option
                                                                                        value="<?php echo e($key); ?>"
                                                                                        <?php if(!empty($bank)): ?>
                                                                                        <?php if(strtoupper($bank->currency) == $key): ?> selected <?php endif; ?>
                                                                                        <?php endif; ?>
                                                                                    >
                                                                                        <?php echo e($key); ?>

                                                                                    </option>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            </select>
                                                                            <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Dashboard Box -->
                                            <div class="col-xl-12">
                                                <input type="hidden" name="type" value="paypal">
                                                <button type="submit" class="button ripple-effect big margin-top-30">
                                                    Save Changes
                                                </button>
                                            </div>

                                        </div>
                                        <!-- Row / End -->
                                    </form>
                                </div>
                                <div class="tab-pane fade" id="withdraw-request" role="tabpanel">
                                    <form action="<?php echo e(route('withdraw.request')); ?>" method="post"
                                          enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <!-- Row -->
                                        <div class="row">

                                            <!-- Dashboard Box -->
                                            <div class="col-xl-12">
                                                <div class="dashboard-box margin-top-0">
                                                    <!-- Headline -->
                                                    <div class="headline">
                                                        <h3>
                                                            <i class="icon-line-awesome-money"></i>
                                                            <?php echo e(__('Your Balance')); ?> $<?php echo e($balance); ?>

                                                        </h3>
                                                    </div>

                                                    <div class="content with-padding padding-bottom-0">

                                                        <div class="row">
                                                            <div class="col">
                                                                <div class="row">
                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Withdraw Method')); ?></h5>
                                                                            <select id="country"
                                                                                    class="selectpicker with-border <?php $__errorArgs = ['withdraw_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                    data-size="7" title="Select Withdraw Method"
                                                                                    data-live-search="true"
                                                                                    name="withdraw_method">
                                                                                <option value="bank_account">
                                                                                    <?php echo e(__('Bank Account')); ?>

                                                                                </option>
                                                                                <option value="paypal">
                                                                                    <?php echo e(__('Paypal')); ?>

                                                                                </option>
                                                                            </select>
                                                                            <?php $__errorArgs = ['withdraw_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-xl-6">
                                                                        <div class="submit-field">
                                                                            <h5><?php echo e(__('Amount')); ?></h5>
                                                                            <input name="amount"
                                                                                   type="text"
                                                                                   class="with-border <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                                   value="<?php echo e($balance); ?>">
                                                                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <div class="invalid-feedback">
                                                                                <?php echo e($message); ?>

                                                                            </div>
                                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Dashboard Box -->
                                            <div class="col-xl-12">
                                                <button type="submit" class="button ripple-effect big margin-top-30">
                                                    <?php echo e(__('Withdraw')); ?>

                                                </button>
                                            </div>

                                        </div>
                                        <!-- Row / End -->
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- Row / End -->
                <!-- Footer -->
                <div class="dashboard-footer-spacer"></div>
            </div>
        </div>
        <!-- Dashboard Content / End -->

    </div>
    <!-- Dashboard Container / End -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/frontend')); ?>/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/withdraw/index.blade.php ENDPATH**/ ?>