<?php $__env->startSection('title'); ?>
    <?php echo e($job->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Titlebar
    ================================================== -->
    <div class="single-page-header" data-background-image="<?php echo e(frontend_asset('')); ?>/images/single-task.jpg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="single-page-header-inner">
                        <div class="left-side">
                            <div class="header-image">
                                <a href="single-company-profile.html">
                                    <?php if(!empty($job->creatorDetails->profile_pic)): ?>
                                        <img src="<?php echo e(asset('')); ?>/<?php echo e($job->creatorDetails->profile_pic); ?>" alt=""/>
                                    <?php else: ?>
                                        <img
                                            src="<?php echo e(asset('assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                            alt=""/>
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="header-details">
                                <h3><?php echo e($job->title); ?></h3>
                            </div>
                        </div>
                        <div class="right-side">
                            <div class="salary-box">
                                <div class="salary-type"><?php echo e(__('Fee Range')); ?></div>
                                <div class="salary-amount">$<?php echo e($job->fee_range_min); ?> - $<?php echo e($job->fee_range_max); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Page Content
    ================================================== -->
    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <div class="row">

            <!-- Content -->
            <div class="col-xl-12 col-lg-12 content-right-offset">

                <!-- Description -->
                <div class="single-page-section">
                    <h3 class="margin-bottom-25">
                        <?php echo e(__('Job Description')); ?>

                    </h3>
                    <p><?php echo e($job->description); ?></p>
                </div>
                <div class="clearfix"></div>

                <!-- Freelancers Bidding -->
                <div class="boxed-list margin-bottom-60">
                    <div class="boxed-list-headline">
                        <h3>
                            <i class="icon-material-outline-group"></i>
                            <?php echo e(__('Applications')); ?>

                        </h3>
                    </div>
                    <ul class="boxed-list-ul">
                        <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="bid">
                                <!-- Avatar -->
                                <div class="bids-avatar">
                                    <div class="freelancer-avatar">
                                        <div class="verified-badge"></div>
                                        <a href="<?php echo e(route('public.profile',encrypt($application->id))); ?>">
                                            <?php if(!empty($application->candidateDetails->profile_pic)): ?>
                                                <img src="<?php echo e(asset('profile/'.$application->candidateDetails->profile_pic)); ?>" alt=""/>
                                            <?php else: ?>
                                                <img
                                                    src="<?php echo e(asset('assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                    alt=""/>
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                </div>

                                <!-- Content -->
                                <div class="bids-content">
                                    <!-- Name -->
                                    <div class="freelancer-name">
                                        <h4>
                                            <a href="<?php echo e(route('public.profile',encrypt($application->id))); ?>">
                                                <?php echo e($application->candidateDetails->first_name); ?> <?php echo e($application->candidateDetails->last_name); ?>

                                            </a>

                                        </h4>
                                        <?php echo e($application->candidateDetails->userCountry->name); ?>

                                        <?php
                                            $rating = calculateRating($application->candidateDetails->userRating);
                                        ?>
                                        <?php if($rating > 0): ?>
                                            <div class="star-rating" data-rating="<?php echo e($rating); ?>"></div>
                                        <?php else: ?>
                                            <div><?php echo e(__('No Rating')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="application-details">
                                        <p class="show-read-more">
                                            <?php echo e($application->cover_letter); ?>

                                        </p>
                                        <div class="seller-contact">
                                            <a href="<?php echo e(route('message',$application->candidateDetails->id)); ?>" class="apply-now-button d-inline-block">
                                                <?php echo e(__('Send Message')); ?>

                                                <i class="icon-material-outline-arrow-right-alt"></i>
                                            </a>
                                            <?php if($jobStatus == false): ?>
                                                <a href="<?php echo e(route('job.checkout',[encrypt($jobId),encrypt($application->candidateDetails->id)])); ?>" class="apply-now-button d-inline-block">
                                                    <?php echo e(__('Accept Application')); ?>

                                                    <i class="icon-material-outline-arrow-right-alt"></i>
                                                </a>
                                            <?php endif; ?>

                                        </div>
                                    </div>
                                </div>
                                <div class="bids-bid">
                                    <div class="bid-rate">
                                        <span><?php echo e(__('Bid Amount')); ?></span>
                                        <div class="rate">$<?php echo e($application->bid_amount); ?></div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

            </div>

        </div>
    </div>


    <!-- Spacer -->
    <div class="margin-top-15"></div>
    <!-- Spacer / End-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            var maxLength = 300;
            $(".show-read-more").each(function(){
                var myStr = $(this).text();
                if($.trim(myStr).length > maxLength){
                    var newStr = myStr.substring(0, maxLength);
                    var removedStr = myStr.substring(maxLength, $.trim(myStr).length);
                    $(this).empty().html(newStr);
                    $(this).append(' <a href="javascript:void(0);" class="read-more">read more...</a>');
                    $(this).append('<span class="more-text">' + removedStr + '</span>');
                }
            });
            $(".read-more").click(function(){
                $(this).siblings(".more-text").contents().unwrap();
                $(this).remove();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/job/applications.blade.php ENDPATH**/ ?>