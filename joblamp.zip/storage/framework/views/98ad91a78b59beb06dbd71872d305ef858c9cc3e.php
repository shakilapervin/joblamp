<?php $__env->startSection('title'); ?>
    <?php echo e(__('Accessibility')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="single-page-header" data-background-image="<?php echo e(frontend_asset('')); ?>/images/single-company.jpg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="single-page-header-inner">
                        <div class="left-side">
                            <div class="header-details">
                                <h3><?php echo e(__('Accessibility')); ?></h3>
                            </div>
                        </div>
                        <div class="right-side">
                            <!-- Breadcrumbs -->
                            <nav id="breadcrumbs" class="white">
                                <ul>
                                    <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                                    <li><?php echo e(__('Accessibility')); ?></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="background-image-container"
             style="background-image: url(<?php echo e(frontend_asset('')); ?>/images/single-company.jpg);"></div>
    </div>
    <div class="margin-top-80"></div>
    <!-- Page Content
    ================================================== -->
    <div class="container">
        <div class="row">

            <div class="col-xl-12">
                <p><?php echo $content->data; ?></p>
            </div>

        </div>
    </div>
    <div class="margin-top-80"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .pricing-plan:last-of-type {
            border-right: 1px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/pages/accessibility.blade.php ENDPATH**/ ?>