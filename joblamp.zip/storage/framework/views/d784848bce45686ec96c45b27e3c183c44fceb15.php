<?php $__env->startSection('title'); ?>
    <?php echo e(__('Find Task Worker')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Spacer -->
    <div class="margin-top-90"></div>
    <!-- Spacer / End-->

    <!-- Page Content
    ================================================== -->
    <div class="container">
        <div class="row">












































































































            <div class="col-xl-12 col-lg-12 content-left-offset">

                <h3 class="page-title">Search Results</h3>


















                <!-- Freelancers List Container -->
                <div class="freelancers-container freelancers-grid-layout margin-top-35">
                    <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $worker): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--Freelancer -->
                    <div class="freelancer">

                        <!-- Overview -->
                        <div class="freelancer-overview">
                            <div class="freelancer-overview-inner">
                                <!-- Avatar -->
                                <div class="freelancer-avatar">
                                    <div class="verified-badge"></div>
                                    <a href="<?php echo e(route('public.profile',encrypt($worker->id))); ?>">
                                        <?php if(!empty($worker->profile_pic)): ?>
                                            <img src="<?php echo e(asset('public/profile')); ?>/<?php echo e($worker->profile_pic); ?>"
                                                 alt=""/>
                                        <?php else: ?>
                                            <img
                                                src="<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                alt=""/>
                                        <?php endif; ?>
                                    </a>
                                </div>

                                <!-- Name -->
                                <div class="freelancer-name">
                                    <h4>
                                        <a href="<?php echo e(route('public.profile',encrypt($worker->id))); ?>">
                                            <?php echo e($worker->first_name); ?> <?php echo e($worker->last_name); ?>

                                        </a>
                                    </h4>
                                </div>

                                <!-- Rating -->
                                <div class="freelancer-rating">
                                    <div class="star-rating" data-rating="<?php echo e(calculateRating($worker->userRating)); ?>"></div>
                                </div>
                            </div>
                        </div>

                        <!-- Details -->
                        <div class="freelancer-details">
                            <div class="freelancer-details-list">
                                <ul>
                                    <li><?php echo e(__('Location')); ?> <strong><i class="icon-material-outline-location-on"></i>
                                            <?php echo e($worker->country_name); ?></strong></li>
                                    <li><?php echo e(__('Total Reviews')); ?> <strong><?php echo e(count($worker->userRating)); ?></strong></li>
                                </ul>
                            </div>
                            <a href="<?php echo e(route('public.profile',encrypt($worker->id))); ?>" class="button button-sliding-icon ripple-effect"> <?php echo e(__('View Profile')); ?> <i class="icon-material-outline-arrow-right-alt"></i></a>
                        </div>
                    </div>
                    <!-- Freelancer / End -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!-- Freelancers Container / End -->


                <!-- Pagination -->
                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12">
                        <!-- Pagination -->
                        <div class="pagination-container margin-top-40 margin-bottom-60">
                            <?php echo e($workers->links()); ?>

                        </div>
                    </div>
                </div>
                <!-- Pagination / End -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/freelancer/list.blade.php ENDPATH**/ ?>