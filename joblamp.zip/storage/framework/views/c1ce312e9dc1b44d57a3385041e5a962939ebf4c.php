<?php $__env->startSection('title'); ?>
    <?php echo e(__('Withdraw Details')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-container">

        <!-- Page header start -->
        <div class="page-header">

            <!-- Breadcrumb start -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><?php echo e(__('Withdraw Details')); ?></li>
            </ol>
            <!-- Breadcrumb end -->

        </div>
        <!-- Page header end -->

        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="invoice-container">
                            <div class="invoice-header">
                                <div class="row gutters">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                        <div class="custom-actions-btns mb-5">
                                            <?php if($withdrawData->status != 'paid'): ?>
                                            <a href="<?php echo e(route('admin.mark.withdraw.request.paid',$withdrawData->id)); ?>" class="btn btn-success">
                                                <i class="icon-check"></i> <?php echo e(__('Mark As Paid')); ?>

                                            </a>
                                            <?php else: ?>
                                                <a href="javascrip:void(0);" class="btn btn-success">
                                                    <i class="icon-check"></i> <?php echo e(__('Paid')); ?>

                                                </a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <!-- Row start -->
                                <div class="row gutters">
                                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                                        <div class="invoice-details">
                                            <address>
                                                <?php echo e($userData->first_name); ?> <?php echo e($userData->last_name); ?>

                                            </address>
                                            <address>
                                                <?php echo e($userData->email); ?>

                                            </address>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                                        <div class="invoice-details">
                                            <div class="invoice-num">
                                                <div><?php echo e(__('ID')); ?> <?php echo e($withdrawData->id); ?></div>
                                                <div><?php echo e($withdrawData->created_at); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Row end -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->
        <!-- Row start -->
        <div class="row gutters">
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="invoice-status">
                    <i class="icon-attach_money"></i>
                    <h2 class="status"><?php echo e($withdrawData->amount); ?></h2>
                    <h6 class="badge badge-success"><?php echo e(__('Withdraw Amount')); ?></h6>
                </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                <div class="invoice-status">
                    <i class="icon-account_box"></i>
                    <h2 class="status"><?php echo e(ucfirst($withdrawData->method)); ?></h2>
                    <?php if($withdrawData->method == 'bank'): ?>
                        <p><?php echo e(__('Account Holder Name')); ?> : <?php echo e($accountData->account_holder_name); ?></p>
                        <p><?php echo e(__('Account Type')); ?> : <?php echo e($accountData->account_holder_type); ?></p>
                        <p><?php echo e(__('Routing Number')); ?> : <?php echo e($accountData->routing_number); ?></p>
                        <p><?php echo e(__('Account Number')); ?> : <?php echo e($accountData->account_number); ?></p>
                        <p><?php echo e(__('Currency')); ?> : <?php echo e($accountData->currency); ?></p>
                        <p><?php echo e(__('Country')); ?> : <?php echo e($countries->where('cca2', $accountData->country)->first()->name->common); ?></p>
                    <?php else: ?>
                        <p><?php echo e(__('Account Number')); ?> : <?php echo e($accountData->account_number); ?></p>
                        <p><?php echo e(__('Currency')); ?> : <?php echo e($accountData->currency); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- Row end -->

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/admin/withdraw/details.blade.php ENDPATH**/ ?>