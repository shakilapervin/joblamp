<?php $__env->startSection('title'); ?>
    <?php echo e(__('Messages')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Dashboard Container -->
    <div class="dashboard-container">
    <?php echo $__env->make('frontend.layouts.dashboard-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Dashboard Content
        ================================================== -->
        <div class="dashboard-content-container" data-simplebar>
            <div class="dashboard-content-inner">

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3>Messages</h3>

                    <!-- Breadcrumbs -->
                    <nav id="breadcrumbs" class="dark">
                        <ul>
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Dashboard</a></li>
                            <li>Messages</li>
                        </ul>
                    </nav>
                </div>

                <div class="messages-container margin-top-0">

                    <div class="messages-container-inner">

                        <!-- Messages -->
                        <div class="messages-inbox">
                            <div class="messages-headline">
                                <div class="input-with-icon">
                                    <input id="autocomplete-input" type="text" placeholder="Search">
                                    <i class="icon-material-outline-search"></i>
                                </div>
                            </div>

                            <ul>
                                <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('message',$contact->receiver->id)); ?>">
                                            <div class="message-avatar">
                                                
                                                <?php if(!empty($contact->receiver->profile_pic)): ?>
                                                    <img
                                                        src="<?php echo e(asset('profile/'.$contact->receiver->profile_pic)); ?>"
                                                        alt=""/>
                                                <?php else: ?>
                                                    <img
                                                        src="<?php echo e(asset('assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                        alt=""/>
                                                <?php endif; ?>
                                            </div>

                                            <div class="message-by">
                                                <div class="message-by-headline">
                                                    <h5><?php echo e($contact->receiver->first_name); ?> <?php echo e($contact->receiver->last_name); ?></h5>
                                                    <span>2 days ago</span>
                                                </div>
                                                <p>Yes, I received payment. Thanks for cooperation!</p>
                                            </div>
                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- Messages / End -->

                        <!-- Message Content -->
                        <div class="message-content">

                            <!-- Message Content Inner -->
                            <div class="message-content-inner">
                                <h3>
                                    <?php echo e(__('Please select user to start chat')); ?>

                                </h3>
                            </div>
                        </div>
                        <!-- Message Content -->

                    </div>
                </div>
                <!-- Messages Container / End -->


                <!-- Footer -->
                <div class="dashboard-footer-spacer"></div>

            </div>
        </div>
        <!-- Dashboard Content / End -->
    </div>
    <!-- Dashboard Container / End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/message/index.blade.php ENDPATH**/ ?>