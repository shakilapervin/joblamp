<?php $__env->startSection('title'); ?>
    <?php echo e(__('Completed Jobs')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Dashboard Container -->
    <div class="dashboard-container">
        <?php echo $__env->make('frontend.layouts.dashboard-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="dashboard-content-container">
            <div class="dashboard-content-inner" style="min-height: 523px;">

                <!-- Dashboard Headline -->
                <div class="dashboard-headline">
                    <h3><?php echo e(__('Completed Jobs')); ?></h3>

                    <!-- Breadcrumbs -->
                    <nav id="breadcrumbs" class="dark">
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                            <li><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a></li>
                            <li><?php echo e(__('Completed Jobs')); ?></li>
                        </ul>
                    </nav>
                </div>

                <!-- Row -->
                <div class="row">

                    <!-- Dashboard Box -->
                    <div class="col-xl-12">
                        <div class="dashboard-box margin-top-0">

                            <!-- Headline -->
                            <div class="headline">
                                <h3><i class="icon-material-outline-business-center"></i> <?php echo e(__('Completed Job List')); ?>

                                </h3>
                            </div>

                            <div class="content">
                                <ul class="dashboard-box-list">
                                    <?php if(!empty($jobs)): ?>
                                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applied): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <!-- Job Listing -->
                                                <div class="job-listing">
                                                    <!-- Job Listing Details -->
                                                    <div class="job-listing-details">
                                                        <!-- Details -->
                                                        <div class="job-listing-description">
                                                            <h3 class="job-listing-title">
                                                                <a href="<?php echo e(route('job.details',encrypt($applied->id))); ?>">
                                                                    <?php echo e($applied->title); ?>

                                                                </a>
                                                            </h3>

                                                            <!-- Job Listing Footer -->
                                                            <div class="job-listing-footer">
                                                                <ul>
                                                                    <li>
                                                                        <i class="icon-material-outline-date-range"></i>
                                                                        <?php echo e(__('Posted On')); ?>

                                                                        : <?php echo e($applied->created_at->toDateString()); ?>

                                                                    </li>
                                                                    <li>
                                                                        <?php echo e(__('Job ID')); ?>

                                                                        : <?php echo e($applied->job_id); ?>

                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <!-- Buttons -->
                                                <div class="buttons-to-right always-visible">
                                                    <a href="<?php echo e(route('manage.my.job',encrypt($applied->id))); ?>"
                                                       class="button ripple-effect"><i
                                                            class="icon-feather-eye"></i> <?php echo e(__('View Details')); ?></a>
                                                </div>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- Row / End -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/customer/completed-jobs.blade.php ENDPATH**/ ?>