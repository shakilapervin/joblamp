<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="<?php if($contact->receiver->id == $receiver): ?> active-message <?php endif; ?>">
        <a href="<?php echo e(route('message',$contact->receiver->id)); ?>">
            <div class="message-avatar">
                
                <?php if(!empty($contact->receiver->profile_pic)): ?>
                    <img
                        src="<?php echo e(asset('profile/'.$contact->receiver->profile_pic)); ?>"
                        alt=""/>
                <?php else: ?>
                    <img
                        src="<?php echo e(asset('assets/frontend')); ?>/images/user-avatar-placeholder.png"
                        alt=""/>
                <?php endif; ?>
            </div>

            <div class="message-by">
                <div class="message-by-headline">
                    <h5><?php echo e($contact->receiver->first_name); ?> <?php echo e($contact->receiver->last_name); ?></h5>
                </div>
            </div>
        </a>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/partials/contacts.blade.php ENDPATH**/ ?>