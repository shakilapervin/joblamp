<?php $__env->startSection('title'); ?>
    <?php echo e($job->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Titlebar
    ================================================== -->
    <div class="single-page-header" data-background-image="<?php echo e(frontend_asset('')); ?>/images/single-job.jpg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="single-page-header-inner">
                        <div class="left-side">
                            <div class="header-image">
                                <a href="single-company-profile.html">
                                    <?php if(!empty($job->creatorDetails->profile_pic)): ?>
                                        <img src="<?php echo e(asset('')); ?>/<?php echo e($job->creatorDetails->profile_pic); ?>" alt=""/>
                                    <?php else: ?>
                                        <img
                                            src="<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                            alt=""/>
                                    <?php endif; ?>
                                </a>
                            </div>
                            <div class="header-details">
                                <h3><?php echo e($job->title); ?></h3>
                                <h5>
                                    <?php echo e(__('About the Employer')); ?>

                                </h5>
                                <ul>
                                    <li>
                                        <a href="single-company-profile.html">
                                            <i class="icon-material-outline-business"></i>
                                            <?php echo e($job->creatorDetails->first_name); ?> <?php echo e($job->creatorDetails->last_name); ?>

                                        </a>
                                    </li>
                                    <li>
                                        <div class="star-rating" data-rating="4.9"></div>
                                    </li>
                                    <li>
                                        <?php echo e($job->creatorDetails->userCountry->name); ?>

                                    </li>
                                    <li>
                                        <div class="verified-badge-with-title">Verified</div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="right-side">
                            <div class="salary-box">
                                <div class="salary-type"><?php echo e(__('Fee Range')); ?></div>
                                <div class="salary-amount">$<?php echo e($job->fee_range_min); ?> - $<?php echo e($job->fee_range_max); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Page Content
    ================================================== -->
    <div class="container">
        <div class="row">

        <!-- Content -->
            <div class="col-xl-8 col-lg-8 content-right-offset">

                <div class="single-page-section">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    <h3 class="margin-bottom-25">
                        <?php echo e(__('Job Description')); ?>

                    </h3>
                    <p>
                        <?php echo e($job->description); ?>

                    </p>
                </div>
                <?php if(count($similarJobs) > 0): ?>
                    <div class="single-page-section">
                        <h3 class="margin-bottom-25">
                            <?php echo e(__('Similar Jobs')); ?>

                        </h3>
                        <!-- Listings Container -->
                        <div class="listings-container grid-layout">
                        <?php $__currentLoopData = $similarJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similarJob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <!-- Job Listing -->
                                <a href="#" class="job-listing">

                                    <!-- Job Listing Details -->
                                    <div class="job-listing-details">
                                        <!-- Logo -->
                                        <div class="job-listing-company-logo">
                                            <?php if(!empty($similarJob->creatorDetails->profile_pic)): ?>
                                                <img src="<?php echo e(asset('')); ?>/<?php echo e($job->creatorDetails->profile_pic); ?>"
                                                     alt=""/>
                                            <?php else: ?>
                                                <img
                                                    src="<?php echo e(asset('public/assets/frontend')); ?>/images/user-avatar-placeholder.png"
                                                    alt=""/>
                                            <?php endif; ?>
                                        </div>

                                        <!-- Details -->
                                        <div class="job-listing-description">
                                            <h4 class="job-listing-company">
                                                <?php echo e($similarJob->creatorDetails->first_name); ?> <?php echo e($similarJob->creatorDetails->last_name); ?>

                                            </h4>
                                            <h3 class="job-listing-title">
                                                <?php echo e($similarJob->title); ?>

                                            </h3>
                                        </div>
                                    </div>

                                    <!-- Job Listing Footer -->
                                    <div class="job-listing-footer">
                                        <ul>
                                            <li>
                                                <i class="icon-material-outline-location-on"></i>
                                                <?php echo e($similarJob->jobCountry->name); ?>

                                            </li>
                                            <li>
                                                <i class="icon-material-outline-account-balance-wallet"></i>
                                                $<?php echo e($similarJob->fee_range_min); ?> - $<?php echo e($similarJob->fee_range_max); ?>

                                            </li>
                                            <li>
                                                <i class="icon-material-outline-access-time"></i>
                                                <?php echo e($similarJob->created_at->diffForHumans()); ?>

                                            </li>
                                        </ul>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <!-- Listings Container / End -->

                    </div>
                <?php endif; ?>
            </div>


            <!-- Sidebar -->
            <div class="col-xl-4 col-lg-4">
                <div class="sidebar-container">
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'service_provider' && \App\JobApplication::where('job_id',$job->id)->where('candidate_id',\Illuminate\Support\Facades\Auth::user()->id)->count() <= 0): ?>
                            <a href="#small-dialog" class="apply-now-button popup-with-zoom-anim">
                                <?php echo e(__('Apply Now ')); ?>

                                <i class="icon-material-outline-arrow-right-alt"></i>
                            </a>
                        <?php endif; ?>
                        <?php if(\App\JobApplication::where('job_id',$job->id)->where('candidate_id',\Illuminate\Support\Facades\Auth::user()->id)->count() > 0): ?>
                                <a href="javascript:void(0);" class="apply-now-button popup-with-zoom-anim">
                                    <?php echo e(__('Already Applied')); ?>

                                    <i class="icon-material-outline-arrow-right-alt"></i>
                                </a>
                        <?php endif; ?>
                    <?php endif; ?>
                <!-- Sidebar Widget -->
                    <div class="sidebar-widget">
                        <div class="job-overview">
                            <div class="job-overview-headline">
                                <?php echo e(__('Job Summary')); ?>

                            </div>
                            <div class="job-overview-inner">
                                <ul>
                                    <li>
                                        <i class="icon-material-outline-location-on"></i>
                                        <span><?php echo e(__('Location')); ?></span>
                                        <h5>
                                            <?php echo e($job->jobCountry->name); ?>

                                        </h5>
                                    </li>
                                    <li>
                                        <i class="icon-material-outline-local-atm"></i>
                                        <span><?php echo e(__('Fee Range')); ?></span>
                                        <h5>$<?php echo e($job->fee_range_min); ?> - $<?php echo e($job->fee_range_max); ?></h5>
                                    </li>
                                    <li>
                                        <i class="icon-material-outline-access-time"></i>
                                        <span>
                                            <?php echo e(__('Date Posted')); ?>

                                        </span>
                                        <h5>
                                            <?php echo e($job->created_at->diffForHumans()); ?>

                                        </h5>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Sidebar Widget -->
                    <div class="sidebar-widget">
                        <h3><?php echo e(__('Share Job')); ?></h3>

                        <!-- Copy URL -->
                        <div class="copy-url">
                            <input id="copy-url" type="text" value="" class="with-border">
                            <button class="copy-url-button ripple-effect" data-clipboard-target="#copy-url"
                                    title="Copy to Clipboard" data-tippy-placement="top"><i
                                    class="icon-material-outline-file-copy"></i></button>
                        </div>

                        <!-- Share Buttons -->
                        <div class="share-buttons margin-top-25">
                            <div class="share-buttons-trigger"><i class="icon-feather-share-2"></i></div>
                            <div class="share-buttons-content">
                                <span><?php echo e(__('Interesting')); ?>? <strong><?php echo e(__('Share It')); ?>!</strong></span>
                                <ul class="share-buttons-icons">
                                    <li><a href="#" data-button-color="#3b5998" title="Share on Facebook"
                                           data-tippy-placement="top"><i class="icon-brand-facebook-f"></i></a></li>
                                    <li><a href="#" data-button-color="#1da1f2" title="Share on Twitter"
                                           data-tippy-placement="top"><i class="icon-brand-twitter"></i></a></li>
                                    <li><a href="#" data-button-color="#dd4b39" title="Share on Google Plus"
                                           data-tippy-placement="top"><i class="icon-brand-google-plus-g"></i></a></li>
                                    <li><a href="#" data-button-color="#0077b5" title="Share on LinkedIn"
                                           data-tippy-placement="top"><i class="icon-brand-linkedin-in"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!--
    Apply for a job popup
    ==================================================
    -->
    <?php if(auth()->guard()->check()): ?>
        <?php if(\Illuminate\Support\Facades\Auth::user()->user_type == 'service_provider' && \App\JobApplication::where('job_id',$job->id)->where('candidate_id',\Illuminate\Support\Facades\Auth::user()->id)->count() <= 0): ?>
    <div id="small-dialog" class="zoom-anim-dialog mfp-hide dialog-with-tabs">
        <!--Tabs -->
        <div class="sign-in-form">
            <ul class="popup-tabs-nav">
                <li>
                    <a href="#tab">
                        <?php echo e(__('Apply Now')); ?>

                    </a>
                </li>
            </ul>
            <div class="popup-tabs-container">

                <!-- Tab -->
                <div class="popup-tab-content" id="tab">

                    <!-- Welcome Text -->
                    <div class="welcome-text">
                        <h3>
                            <?php echo e(__('Write Your Cover Letter')); ?>

                        </h3>
                    </div>

                    <!-- Form -->
                    <form method="post" id="apply-now-form" action="<?php echo e(route('apply-job')); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="id" value="<?php echo e(encrypt($job->id)); ?>">
                        <input type="hidden" name="candidate_id"
                               value="<?php echo e(encrypt(\Illuminate\Support\Facades\Auth::user()->id)); ?>">
                        <div class="input-with-icon-left">
                            <textarea name="cover_letter"
                                      class="input-text with-border <?php $__errorArgs = ['cover_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      cols="30" rows="10" required></textarea>
                            <?php $__errorArgs = ['cover_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="input-with-icon-left">
                            <input class="input-text with-border <?php $__errorArgs = ['bid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="bid_amount" placeholder="<?php echo e(__('Offer Amount')); ?>" style="padding-left: 20px;">
                            <?php $__errorArgs = ['bid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- Button -->
                        <?php if(\Illuminate\Support\Facades\Auth::user()->remain_job > 0 || \Illuminate\Support\Facades\Auth::user()->remain_job != 'unlimited'): ?>
                            <button class="button margin-top-35 full-width button-sliding-icon ripple-effect" type="submit"
                                    form="apply-now-form"><?php echo e(__('Apply Now')); ?>

                                <i class="icon-material-outline-arrow-right-alt"></i>
                            </button>
                        <?php else: ?>
                            <button class="button margin-top-35 full-width button-sliding-icon ripple-effect" type="submit"
                                    form="apply-now-form"><?php echo e(__('Apply Now')); ?> <?php echo e(__('and Pay')); ?> $2
                                <i class="icon-material-outline-arrow-right-alt"></i>
                            </button>
                        <?php endif; ?>
                    </form>

                </div>

            </div>
        </div>
    </div>
    <!-- Apply for a job popup / End -->
        <?php endif; ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        // Snackbar for copy to clipboard button
        $('.copy-url-button').click(function () {
            Snackbar.show({
                text: '<?php echo e(__('Copied to clipboard!')); ?>',
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/job/single.blade.php ENDPATH**/ ?>