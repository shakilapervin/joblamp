<?php $__env->startSection('style'); ?>
    <!-- Data Tables -->
    <link rel="stylesheet" href="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.bs4.css"/>
    <link rel="stylesheet" href="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.bs4-custom.css"/>
    <link href="<?php echo e(admin_asset('')); ?>/vendor/datatables/buttons.bs.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    <?php if(Route::is('admin.withdraw.not.paid')): ?>
        <?php echo e(__('New Withdraw Request List')); ?>

    <?php else: ?>
        <?php echo e(__('Paid Withdraw Request List')); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Main container start -->
    <div class="main-container">

        <!-- Page header start -->
        <div class="page-header">

            <!-- Breadcrumb start -->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <?php if(Route::is('admin.withdraw.not.paid')): ?>
                        <?php echo e(__('New Withdraw Request List')); ?>

                    <?php else: ?>
                        <?php echo e(__('Paid Withdraw Request List')); ?>

                    <?php endif; ?>
                </li>
            </ol>
            <!-- Breadcrumb end -->
        </div>
        <!-- Page header end -->

        <!-- Row start -->
        <div class="row gutters">
            <div class="col-sm-12">
                <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('error')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(Session::has('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert"
                         style="width: 100%;">
                        <?php echo e(Session::get('success')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="card-title">
                            <?php if(Route::is('admin.withdraw.not.paid')): ?>
                                <?php echo e(__('New Withdraw Request List')); ?>

                            <?php else: ?>
                                <?php echo e(__('Paid Withdraw Request List')); ?>

                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="datatable table table-bordered">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th><?php echo e(__('Name')); ?></th>
                                    <th><?php echo e(__('Email')); ?></th>
                                    <th><?php echo e(__('Withdraw Method')); ?></th>
                                    <th><?php echo e(__('Amount')); ?></th>
                                    <th><?php echo e(__('Date')); ?></th>
                                    <th><?php echo e(__('Action')); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
                                    $sl = 0;
                                ?>
                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $sl++;
                                    ?>
                                    <tr>
                                        <td>
                                            <?php echo e($sl); ?>

                                        </td>
                                        <td>
                                            <?php
                                                $user = \App\User::where('id',$row->user_id)->first();
                                            ?>
                                            <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($user->email); ?>

                                        </td>
                                        <td>
                                            <?php echo e(ucfirst($row->method)); ?>

                                        </td>
                                        <td>
                                            <?php echo e($row->amount); ?>

                                        </td>
                                        <td>
                                            <?php echo e($row->created_at); ?>

                                        </td>
                                        <td>
                                            <a class="btn btn-info" href="<?php echo e(route('admin.withdraw.request.view', $row->id)); ?>"><?php echo e(__('Details')); ?></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row end -->

    </div>
    <!-- Main container end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Data Tables -->
    <script src="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.min.js"></script>
    <script src="<?php echo e(admin_asset('')); ?>/vendor/datatables/dataTables.bootstrap.min.js"></script>
    <!-- Custom Data tables -->
    <script>
        $(document).ready(function () {
            $('.datatable').dataTable();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/admin/withdraw/index.blade.php ENDPATH**/ ?>