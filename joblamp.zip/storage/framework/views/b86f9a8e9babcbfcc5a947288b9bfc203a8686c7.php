<?php $__env->startSection('title'); ?>
    <?php echo e(__('Lotto Prizes')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="single-page-header" data-background-image="<?php echo e(frontend_asset('')); ?>/images/single-company.jpg">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="single-page-header-inner">
                        <div class="left-side">
                            <div class="header-details">
                                <h3><?php echo e(__('Lotto Prizes')); ?></h3>
                            </div>
                        </div>
                        <div class="right-side">
                            <!-- Breadcrumbs -->
                            <nav id="breadcrumbs" class="white">
                                <ul>
                                    <li><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Home')); ?></a></li>
                                    <li><?php echo e(__('Lotto Prizes')); ?></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="background-image-container"
             style="background-image: url(<?php echo e(frontend_asset('')); ?>/images/single-company.jpg);"></div>
    </div>
    <div class="margin-top-80"></div>
    <!-- Page Content
    ================================================== -->
    <div class="container">
        <div class="row">

            <div class="col-xl-12">

                <!-- Pricing Plans Container -->
                <div class="pricing-plans-container">
                <?php $__currentLoopData = $prizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Prize -->
                        <div class="pricing-plan" style="border-left: 1px solid;border-bottom: 1px solid; border-top: 1px solid;">
                            <h3><?php echo e($prize->title); ?></h3>
                            <div class="pricing-plan-features">
                                <p>
                                    <?php echo $prize->details; ?>

                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </div>

        </div>
    </div>
    <div class="margin-top-80"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .pricing-plan:last-of-type {
            border-right: 1px solid;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\joblamp\resources\views/frontend/pages/prize.blade.php ENDPATH**/ ?>